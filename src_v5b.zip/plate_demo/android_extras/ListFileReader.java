package com.apexmobilelabs.plate_demo;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Reads every cell of a defaulter list as plain text. Works with Excel (.xlsx) and
 * CSV / text files. Plain Java only, so it can be tested on a computer.
 */
public final class ListFileReader {
  private ListFileReader() {}

  private static final Pattern SI = Pattern.compile("<si\\b[^>]*>(.*?)</si>", Pattern.DOTALL);
  private static final Pattern T = Pattern.compile("<t\\b[^>]*>(.*?)</t>", Pattern.DOTALL);
  private static final Pattern CELL =
      Pattern.compile("<c\\b([^>]*?)(?:/>|>(.*?)</c>)", Pattern.DOTALL);
  private static final Pattern TYPE = Pattern.compile("\\bt=\"([^\"]*)\"");
  private static final Pattern V = Pattern.compile("<v\\b[^>]*>(.*?)</v>", Pattern.DOTALL);

  /** All cell texts, in sheet order. */
  public static List<String> read(byte[] data) throws IOException {
    if (data.length >= 2 && data[0] == 'P' && data[1] == 'K') return readXlsx(data);
    return readText(data);
  }

  static List<String> readText(byte[] data) {
    String s = new String(data, StandardCharsets.UTF_8);
    if (!s.isEmpty() && s.charAt(0) == '\uFEFF') s = s.substring(1);
    List<String> out = new ArrayList<>();
    for (String line : s.split("\\r?\\n|\\r")) {
      for (String cell : line.split("[,;\\t|]")) {
        String c = cell.trim();
        if (c.length() >= 2 && c.startsWith("\"") && c.endsWith("\"")) c = c.substring(1, c.length() - 1);
        if (!c.isEmpty()) out.add(c);
      }
    }
    return out;
  }

  static List<String> readXlsx(byte[] data) throws IOException {
    Map<String, String> files = new HashMap<>();
    try (ZipInputStream zip = new ZipInputStream(new java.io.ByteArrayInputStream(data))) {
      ZipEntry e;
      while ((e = zip.getNextEntry()) != null) {
        String name = e.getName();
        if (name.equals("xl/sharedStrings.xml")
            || (name.startsWith("xl/worksheets/sheet") && name.endsWith(".xml"))) {
          files.put(name, new String(readAll(zip), StandardCharsets.UTF_8));
        }
      }
    }
    List<String> shared = new ArrayList<>();
    String ss = files.get("xl/sharedStrings.xml");
    if (ss != null) {
      Matcher m = SI.matcher(ss);
      while (m.find()) {
        StringBuilder sb = new StringBuilder();
        Matcher t = T.matcher(m.group(1));
        while (t.find()) sb.append(t.group(1));
        shared.add(unescape(sb.toString()));
      }
    }
    // sheet1.xml, sheet2.xml ... in number order
    TreeMap<Integer, String> sheets = new TreeMap<>();
    for (Map.Entry<String, String> f : files.entrySet()) {
      String n = f.getKey();
      if (!n.startsWith("xl/worksheets/sheet")) continue;
      String num = n.substring("xl/worksheets/sheet".length(), n.length() - 4);
      try {
        sheets.put(Integer.parseInt(num), f.getValue());
      } catch (NumberFormatException ignored) {
        sheets.put(1000 + sheets.size(), f.getValue());
      }
    }
    List<String> out = new ArrayList<>();
    for (String sheet : sheets.values()) {
      Matcher c = CELL.matcher(sheet);
      while (c.find()) {
        String attrs = c.group(1);
        String body = c.group(2);
        if (body == null) continue;
        Matcher tm = TYPE.matcher(attrs);
        String type = tm.find() ? tm.group(1) : "";
        String text = null;
        if (type.equals("inlineStr")) {
          StringBuilder sb = new StringBuilder();
          Matcher t = T.matcher(body);
          while (t.find()) sb.append(t.group(1));
          text = unescape(sb.toString());
        } else {
          Matcher v = V.matcher(body);
          if (v.find()) {
            String raw = v.group(1).trim();
            if (type.equals("s")) {
              try {
                int idx = Integer.parseInt(raw);
                if (idx >= 0 && idx < shared.size()) text = shared.get(idx);
              } catch (NumberFormatException ignored) {
              }
            } else {
              text = unescape(raw);
            }
          }
        }
        if (text != null && !text.trim().isEmpty()) out.add(text.trim());
      }
    }
    return out;
  }

  private static byte[] readAll(InputStream in) throws IOException {
    ByteArrayOutputStream bo = new ByteArrayOutputStream();
    byte[] buf = new byte[8192];
    int n;
    while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
    return bo.toByteArray();
  }

  private static String unescape(String s) {
    return s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"")
        .replace("&apos;", "'").replace("&amp;", "&");
  }
}
