package com.apexmobilelabs.plate_demo;

import android.app.Activity;
import android.content.Intent;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraMetadata;
import android.hardware.camera2.CaptureRequest;
import android.net.Uri;
import android.speech.tts.TextToSpeech;
import android.util.Range;
import androidx.annotation.NonNull;
import androidx.annotation.OptIn;
import androidx.camera.camera2.interop.Camera2CameraControl;
import androidx.camera.camera2.interop.Camera2CameraInfo;
import androidx.camera.camera2.interop.CaptureRequestOptions;
import androidx.camera.camera2.interop.ExperimentalCamera2Interop;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraInfo;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.UseCase;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.core.content.ContextCompat;
import com.google.common.util.concurrent.ListenableFuture;
import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodChannel;
import java.util.ArrayList;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.List;
import java.util.Map;

/**
 * Lets the Flutter side set a fixed fast shutter speed and ISO.
 *
 * <p>The Flutter camera plugin (camera_android_camerax) binds the camera to this activity.
 * Calling bindToLifecycle with the same activity, the same camera and no use cases returns that
 * same camera, so these settings go onto the session the plugin already opened. Nothing new is
 * opened.
 */
@OptIn(markerClass = ExperimentalCamera2Interop.class)
public class MainActivity extends FlutterActivity {
  private static final String CHANNEL = "platealert/shutter";
  private static final String NATIVE = "platealert/native";
  private static final int PICK_LIST = 4711;

  private TextToSpeech tts;
  private boolean ttsReady = false;
  private MethodChannel.Result pendingPick;

  private interface CameraTask {
    void run(@NonNull Camera camera) throws Exception;
  }

  @Override
  public void configureFlutterEngine(@NonNull FlutterEngine flutterEngine) {
    super.configureFlutterEngine(flutterEngine);
    new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), CHANNEL)
        .setMethodCallHandler(
            (call, result) -> {
              final String id = call.argument("id");
              if (id == null) {
                result.error("args", "missing camera id", null);
                return;
              }
              switch (call.method) {
                case "info":
                  withCamera(id, result, camera -> result.success(info(camera)));
                  break;
                case "manual":
                  {
                    final Number ns = call.argument("ns");
                    final Number iso = call.argument("iso");
                    final Number frameNs = call.argument("frameNs");
                    if (ns == null || iso == null) {
                      result.error("args", "missing ns/iso", null);
                      return;
                    }
                    withCamera(
                        id,
                        result,
                        camera -> {
                          CaptureRequestOptions.Builder b =
                              new CaptureRequestOptions.Builder()
                                  .setCaptureRequestOption(
                                      CaptureRequest.CONTROL_AE_MODE,
                                      CameraMetadata.CONTROL_AE_MODE_OFF)
                                  .setCaptureRequestOption(
                                      CaptureRequest.SENSOR_EXPOSURE_TIME, ns.longValue())
                                  .setCaptureRequestOption(
                                      CaptureRequest.SENSOR_SENSITIVITY, iso.intValue());
                          if (frameNs != null) {
                            b.setCaptureRequestOption(
                                CaptureRequest.SENSOR_FRAME_DURATION, frameNs.longValue());
                          }
                          send(camera, b.build(), result);
                        });
                    break;
                  }
                case "auto":
                  withCamera(
                      id,
                      result,
                      camera ->
                          send(
                              camera,
                              new CaptureRequestOptions.Builder()
                                  .setCaptureRequestOption(
                                      CaptureRequest.CONTROL_AE_MODE,
                                      CameraMetadata.CONTROL_AE_MODE_ON)
                                  .build(),
                              result));
                  break;
                default:
                  result.notImplemented();
              }
            });

    tts =
        new TextToSpeech(
            this,
            status -> {
              if (status == TextToSpeech.SUCCESS && tts != null) {
                int r = tts.setLanguage(Locale.forLanguageTag("en-IN"));
                if (r < 0) tts.setLanguage(Locale.ENGLISH);
                tts.setSpeechRate(0.9f);
                ttsReady = true;
              }
            });

    new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), NATIVE)
        .setMethodCallHandler(
            (call, result) -> {
              switch (call.method) {
                case "speak":
                  {
                    final String text = call.argument("text");
                    if (ttsReady && tts != null && text != null) {
                      tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "plate");
                      result.success(true);
                    } else {
                      result.success(false);
                    }
                    break;
                  }
                case "filesDir":
                  result.success(getFilesDir().getAbsolutePath());
                  break;
                case "pickList":
                  {
                    if (pendingPick != null) {
                      result.error("busy", "already picking", null);
                      return;
                    }
                    pendingPick = result;
                    final Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                    i.putExtra(
                        Intent.EXTRA_MIME_TYPES,
                        new String[] {
                          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                          "text/csv",
                          "text/comma-separated-values",
                          "text/plain",
                          "application/octet-stream"
                        });
                    try {
                      startActivityForResult(i, PICK_LIST);
                    } catch (Exception e) {
                      pendingPick = null;
                      result.error("pick", String.valueOf(e), null);
                    }
                    break;
                  }
                default:
                  result.notImplemented();
              }
            });
  }

  @Override
  protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (requestCode != PICK_LIST) return;
    final MethodChannel.Result r = pendingPick;
    pendingPick = null;
    if (r == null) return;
    if (resultCode != Activity.RESULT_OK || data == null || data.getData() == null) {
      r.success(null); // cancelled
      return;
    }
    final Uri uri = data.getData();
    new Thread(
            () -> {
              try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) throw new java.io.IOException("cannot open file");
                final ByteArrayOutputStream bo = new ByteArrayOutputStream();
                final byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                final List<String> cells = ListFileReader.read(bo.toByteArray());
                runOnUiThread(() -> r.success(cells));
              } catch (Exception e) {
                runOnUiThread(() -> r.error("read", String.valueOf(e), null));
              }
            })
        .start();
  }

  @Override
  protected void onDestroy() {
    if (tts != null) {
      tts.shutdown();
      tts = null;
    }
    super.onDestroy();
  }

  /** Finds the camera the plugin already bound to this activity and runs [task] on it. */
  private void withCamera(
      @NonNull String id, @NonNull MethodChannel.Result result, @NonNull CameraTask task) {
    final ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(this);
    future.addListener(
        () -> {
          try {
            final ProcessCameraProvider provider = future.get();
            final CameraSelector selector =
                new CameraSelector.Builder()
                    .addCameraFilter(
                        infos -> {
                          final List<CameraInfo> out = new ArrayList<>();
                          for (CameraInfo info : infos) {
                            if (id.equals(Camera2CameraInfo.from(info).getCameraId())) {
                              out.add(info);
                            }
                          }
                          return out;
                        })
                    .build();
            final Camera camera = provider.bindToLifecycle(this, selector, new UseCase[0]);
            task.run(camera);
          } catch (Exception e) {
            result.error("shutter", String.valueOf(e), null);
          }
        },
        ContextCompat.getMainExecutor(this));
  }

  @NonNull
  private Map<String, Object> info(@NonNull Camera camera) {
    final Camera2CameraInfo ci = Camera2CameraInfo.from(camera.getCameraInfo());
    final int[] caps =
        ci.getCameraCharacteristic(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES);
    boolean manual = false;
    if (caps != null) {
      for (int c : caps) {
        if (c == CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR) {
          manual = true;
          break;
        }
      }
    }
    final Range<Long> exp =
        ci.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE);
    final Range<Integer> iso =
        ci.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE);
    final Map<String, Object> m = new HashMap<>();
    m.put("manual", manual);
    m.put("minNs", exp != null ? exp.getLower() : 0L);
    m.put("maxNs", exp != null ? exp.getUpper() : 0L);
    m.put("minIso", iso != null ? iso.getLower() : 0);
    m.put("maxIso", iso != null ? iso.getUpper() : 0);
    return m;
  }

  private void send(
      @NonNull Camera camera,
      @NonNull CaptureRequestOptions options,
      @NonNull MethodChannel.Result result) {
    final ListenableFuture<Void> f =
        Camera2CameraControl.from(camera.getCameraControl()).addCaptureRequestOptions(options);
    f.addListener(
        () -> {
          try {
            f.get();
            result.success(true);
          } catch (Exception e) {
            result.error("shutter", String.valueOf(e), null);
          }
        },
        ContextCompat.getMainExecutor(this));
  }
}
