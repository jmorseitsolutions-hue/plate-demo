import 'dart:math';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:plate_demo/scan_core.dart';

Set<String> readPlates(String raw) =>
    PlateReader.plates(PlateReader.pieces([raw]));

void main() {
  group('Plate rules', () {
    test('clean plate', () => expect(readPlates('MH46DF1352'), contains('MH46DF1352')));
    test('spaces and dashes', () => expect(readPlates('MH 46 DF-1352'), contains('MH46DF1352')));
    test('IND prefix', () => expect(readPlates('IND MH46DF1352'), contains('MH46DF1352')));
    test('two-line plate', () => expect(readPlates('MH46\nDF1352'), contains('MH46DF1352')));
    test('O/0 and I/1 mix-ups', () {
      expect(readPlates('MH4GDFI352'), contains('MH46DF1352'));
      expect(readPlates('MHO4AB1234'), contains('MH04AB1234'));
    });
    test('one-letter series', () => expect(readPlates('MH04A1234'), contains('MH04A1234')));
    test('BH series', () => expect(readPlates('22BH1234AA'), contains('22BH1234AA')));
    test('junk gives nothing', () {
      expect(readPlates('HELLO WORLD'), isEmpty);
      expect(readPlates('1234567890'), isEmpty);
      expect(readPlates('CALL 9820012345'), isEmpty);
      expect(readPlates('OPEN 24 HOURS'), isEmpty);
    });
    test('list match works even when plate rule fails', () {
      final cleaned = PlateReader.pieces(['XXMH46DF1352YYZZ']);
      final hits = PlateReader.listHits(cleaned, PlateReader.plates(cleaned), {'MH46DF1352'});
      expect(hits, contains('MH46DF1352'));
    });
    test('list match with O/0 confusion', () {
      final cleaned = PlateReader.pieces(['MHO4AB1234']);
      final hits = PlateReader.listHits(cleaned, {}, {'MH04AB1234'});
      expect(hits, contains('MH04AB1234'));
    });
    test('no false match', () {
      final cleaned = PlateReader.pieces(['MH46DF1353']);
      final hits = PlateReader.listHits(cleaned, PlateReader.plates(cleaned), {'MH46DF1352'});
      expect(hits, isEmpty);
    });
  });

  group('Camera frame conversion', () {
    for (final size in [(640, 480), (1280, 720), (1920, 1080)]) {
      test('all layouts give identical NV21 ${size.$1}x${size.$2}', () {
        final w = size.$1, h = size.$2;
        final rnd = Random(7);
        final y = Uint8List.fromList(List.generate(w * h, (_) => rnd.nextInt(256)));
        final u = Uint8List.fromList(List.generate((w ~/ 2) * (h ~/ 2), (_) => rnd.nextInt(256)));
        final v = Uint8List.fromList(List.generate((w ~/ 2) * (h ~/ 2), (_) => rnd.nextInt(256)));
        final ref = TestFrames.reference(w, h, y, u, v);
        TestFrames.layouts(w, h, y, u, v).forEach((name, planes) {
          final f = toNv21(w, h, planes);
          expect(f.width, w, reason: name);
          expect(f.height, h, reason: name);
          expect(f.bytes, equals(ref), reason: name);
        });
      });
    }
  });

  group('Rotation', () {
    test('landscape back camera', () {
      expect(rotationFor(90, 90), 0);
      expect(rotationFor(90, 270), 180);
      expect(rotationFor(90, 0), 90);
    });
  });

  group('Reading band (crop)', () {
    for (final size in [(1920, 1080), (1280, 720), (1921, 1081)]) {
      for (final rot in [0, 90, 180, 270]) {
        test('band ${size.$1}x${size.$2} rot $rot is even and inside', () {
          final r = bandFor(size.$1, size.$2, rot, 0.9, 0.45);
          for (final v in [r.left, r.top, r.width, r.height]) {
            expect(v % 2, 0);
          }
          expect(r.left + r.width <= size.$1, isTrue);
          expect(r.top + r.height <= size.$2, isTrue);
          final wantW = rot % 180 == 0 ? 0.9 : 0.45;
          expect((r.width / (size.$1 - size.$1 % 2) - wantW).abs() < 0.01, isTrue);
        });
      }
    }

    test('crop copies the right pixels', () {
      const w = 64, h = 48;
      final rnd = Random(3);
      final bytes = Uint8List.fromList(List.generate(w * h * 3 ~/ 2, (_) => rnd.nextInt(256)));
      final f = Nv21Frame(bytes, w, h);
      final r = bandFor(w, h, 0, 0.5, 0.5);
      final c = cropNv21(f, r);
      expect(c.width, r.width);
      expect(c.height, r.height);
      expect(c.bytes.length, r.width * r.height * 3 ~/ 2);
      for (var row = 0; row < r.height; row++) {
        for (var col = 0; col < r.width; col++) {
          expect(c.bytes[row * r.width + col], bytes[(r.top + row) * w + r.left + col]);
        }
      }
      final uv = r.width * r.height;
      for (var row = 0; row < r.height ~/ 2; row++) {
        for (var col = 0; col < r.width; col++) {
          expect(c.bytes[uv + row * r.width + col],
              bytes[w * h + (r.top ~/ 2 + row) * w + r.left + col]);
        }
      }
    });
  });

  group('Sharpness and brightness', () {
    // Bars like plate characters, then the same picture smeared sideways (motion blur).
    Uint8List bars(int w, int h, {int blur = 0}) {
      final img = List<double>.filled(w * h, 200);
      for (var y = h ~/ 3; y < 2 * h ~/ 3; y++) {
        for (var x = 40; x < w - 40; x++) {
          if ((x - 40) % 24 < 8) img[y * w + x] = 20;
        }
      }
      if (blur == 0) return Uint8List.fromList(img.map((v) => v.round()).toList());
      final out = Uint8List(w * h);
      for (var y = 0; y < h; y++) {
        for (var x = 0; x < w; x++) {
          var sum = 0.0;
          var n = 0;
          for (var k = -blur; k <= blur; k++) {
            final xx = x + k;
            if (xx >= 0 && xx < w) {
              sum += img[y * w + xx];
              n++;
            }
          }
          out[y * w + x] = (sum / n).round();
        }
      }
      return out;
    }

    test('sharp picture scores higher than motion-blurred', () {
      const w = 400, h = 200;
      const r = CropRect(0, 0, w, h);
      final sharp = sharpness(bars(w, h), w, r);
      final blurred = sharpness(bars(w, h, blur: 7), w, r);
      expect(sharp > blurred * 2, isTrue, reason: 'sharp=$sharp blurred=$blurred');
    });

    test('flat picture has zero sharpness', () {
      expect(sharpness(Uint8List(400 * 200), 400, const CropRect(0, 0, 400, 200)), 0);
    });

    test('brightness of a flat grey picture', () {
      final y = Uint8List(400 * 200)..fillRange(0, 400 * 200, 100);
      expect(meanLuma(y, 400, const CropRect(0, 0, 400, 200)), 100);
    });
  });

  group('Fixed-shutter brightness control', () {
    // Simple camera model: brightness = scene * shutter * ISO (max 255).
    (double, ExposureSetting) settle(double scene) {
      var cur = const ExposureSetting(2000000, 400);
      double y() => min(255.0, scene * cur.exposureNs * cur.iso / 1e9);
      for (var i = 0; i < 25; i++) {
        final next = nextExposure(
          meanY: y(),
          current: cur,
          targetNs: 2000000,
          slowestNs: 8000000,
          minNs: 20000,
          maxNs: 500000000,
          minIso: 50,
          maxIso: 3200,
        );
        if (next != null) cur = next;
      }
      return (y(), cur);
    }

    test('daylight keeps 1/500 and finds the right brightness', () {
      final (y, cur) = settle(300);
      expect(y, inInclusiveRange(98, 132));
      expect((cur.exposureNs - 2000000).abs() < 50000, isTrue);
    });

    test('shade keeps 1/500 and raises ISO', () {
      final (y, cur) = settle(60);
      expect(y, inInclusiveRange(98, 132));
      expect((cur.exposureNs - 2000000).abs() < 50000, isTrue);
      expect(cur.iso > 400, isTrue);
    });

    test('bright sun uses lowest ISO and an even faster shutter', () {
      final (y, cur) = settle(2000);
      expect(y, inInclusiveRange(98, 132));
      expect(cur.iso, 50);
      expect(cur.exposureNs <= 2000000, isTrue);
    });

    test('very dark never goes slower than the limit', () {
      final (_, cur) = settle(5);
      expect(cur.exposureNs <= 8000000, isTrue);
      expect(cur.iso, 3200);
    });

    test('no change when brightness is already right', () {
      expect(
          nextExposure(
            meanY: 118,
            current: const ExposureSetting(2000000, 400),
            targetNs: 2000000,
            slowestNs: 8000000,
            minNs: 20000,
            maxNs: 500000000,
            minIso: 50,
            maxIso: 3200,
          ),
          isNull);
    });
  });

  group('Voting across reads', () {
    test('three slightly wrong reads agree on the real plate', () {
      final v = PlateVoter();
      expect(v.add({'MH46DF1352'}, 0), isEmpty);
      expect(v.add({'MH46DF1362'}, 100), isEmpty);
      expect(v.add({'MH48DF1352'}, 200), {'MH46DF1352'});
    });
    test('different plates are never merged', () {
      final v = PlateVoter();
      v.add({'MH46DF1352'}, 0);
      v.add({'DL04AB9999'}, 50);
      expect(v.add({'KA01ZZ0001'}, 100), isEmpty);
    });
    test('no answer without a clear majority', () {
      final v = PlateVoter();
      v.add({'MH46DF1352'}, 0);
      v.add({'MH46DF1362'}, 1);
      expect(v.add({'MH46DF1372'}, 2), isEmpty);
    });
    test('old reads expire', () {
      final v = PlateVoter();
      v.add({'MH46DF1352'}, 0);
      v.add({'MH46DF1352'}, 100);
      expect(v.add({'MH46DF1352'}, 5000), isEmpty);
    });
  });

  group('v5: list import, band, photo, voice', () {
    test('finds every plate in spreadsheet cells, ignores the rest', () {
      final cells = [
        'Sr No', 'Customer Name', 'Loan A/c', 'Vehicle No', 'Model', 'EMI Due',
        '1', 'Ramesh Patil', 'LN0098123', 'MH 46 DF 1352', 'Toyota Innova', '23450',
        '2', 'S. Khan & Sons', 'LN0098124', 'mh04ab1234', 'Maruti Swift', '11200',
        '3', 'Priya', 'LN0098125', 'MH-43-BX-0007', 'Hyundai i20', '9800',
        '4', 'Amit', 'LN0098126', '22BH1234AA', 'Kia Seltos', '30500',
        'DL 8C AF 4321', '9820012345',
      ];
      final r = importPlates(cells);
      expect(r.plates, {'MH46DF1352', 'MH04AB1234', 'MH43BX0007', '22BH1234AA', 'DL8CAF4321'});
      expect(r.cells, cells.length);
    });

    test('band on a full-screen picture', () {
      expect(bandOfImage(16 / 9, 16 / 9, 0.9, 0.45), (0.9, 0.45));
      final (w, h) = bandOfImage(9 / 16, 9 / 19.5, 1.0, 1.0);
      expect((w - (9 / 19.5) / (9 / 16)).abs() < 1e-9, isTrue);
      expect(h, 1.0);
    });

    test('NV21 to RGBA colour and size', () {
      const w = 8, h = 4;
      final bytes = Uint8List(w * h * 3 ~/ 2);
      bytes.fillRange(0, w * h, 128);
      for (var i = w * h; i < bytes.length; i += 2) {
        bytes[i] = 200; // V
        bytes[i + 1] = 60; // U
      }
      final (rgba, ow, oh) = nv21ToRgba(Nv21Frame(bytes, w, h));
      expect((ow, oh, rgba.length), (4, 2, 32));
      expect([rgba[0], rgba[1], rgba[2], rgba[3]], [229, 100, 8, 255]);
    });

    test('plate for the voice and the screen', () {
      expect(spokenPlate('MH46DF1352'), 'M H, 4 6, D F, 1 3 5 2');
      expect(spokenPlate('22BH1234AA'), '2 2, B H, 1 2 3 4, A A');
      expect(prettyPlate('MH46DF1352'), 'MH 46 DF 1352');
    });
  });
}
