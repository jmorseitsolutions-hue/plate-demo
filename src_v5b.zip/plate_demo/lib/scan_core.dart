// Pure-Dart logic (no Flutter): plate rules + camera-frame conversion.
// Kept separate so it can be unit-tested on the build server.

import 'dart:typed_data';

/// One colour plane of a camera frame.
class PlaneData {
  final Uint8List bytes;
  final int bytesPerRow;
  final int? bytesPerPixel;
  const PlaneData(this.bytes, this.bytesPerRow, [this.bytesPerPixel]);
}

class Nv21Frame {
  final Uint8List bytes;
  final int width;
  final int height;
  const Nv21Frame(this.bytes, this.width, this.height);
}

/// Builds a tightly packed NV21 buffer (Y rows, then V/U interleaved, no padding)
/// from whatever layout the phone camera gives: 1 plane (NV21, maybe padded)
/// or 3 planes (YUV_420_888 with any row/pixel stride).
Nv21Frame toNv21(int width, int height, List<PlaneData> planes) {
  final w = width - width % 2;
  final h = height - height % 2;
  final out = Uint8List(w * h + (w * h) ~/ 2);
  var idx = 0;

  if (planes.length == 1) {
    final p = planes[0];
    final stride = p.bytesPerRow;
    final b = p.bytes;
    if (stride == w && b.length >= out.length) {
      out.setRange(0, out.length, b);
      return Nv21Frame(out, w, h);
    }
    for (var row = 0; row < h; row++) {
      final start = row * stride;
      final n = _avail(b.length, start, w);
      if (n > 0) out.setRange(idx, idx + n, b, start);
      idx += w;
    }
    final uvStart = stride * height;
    for (var row = 0; row < h ~/ 2; row++) {
      final start = uvStart + row * stride;
      final n = _avail(b.length, start, w);
      if (n > 0) out.setRange(idx, idx + n, b, start);
      for (var k = n < 0 ? 0 : n; k < w; k++) {
        out[idx + k] = 128;
      }
      idx += w;
    }
    return Nv21Frame(out, w, h);
  }

  final y = planes[0], u = planes[1], v = planes[2];
  for (var row = 0; row < h; row++) {
    final start = row * y.bytesPerRow;
    final n = _avail(y.bytes.length, start, w);
    if (n > 0) out.setRange(idx, idx + n, y.bytes, start);
    idx += w;
  }
  final uRow = u.bytesPerRow, uPix = u.bytesPerPixel ?? 1;
  final vRow = v.bytesPerRow, vPix = v.bytesPerPixel ?? 1;
  final ub = u.bytes, vb = v.bytes;
  for (var row = 0; row < h ~/ 2; row++) {
    for (var col = 0; col < w ~/ 2; col++) {
      final vi = row * vRow + col * vPix;
      final ui = row * uRow + col * uPix;
      out[idx++] = vi < vb.length ? vb[vi] : 128;
      out[idx++] = ui < ub.length ? ub[ui] : 128;
    }
  }
  return Nv21Frame(out, w, h);
}

int _avail(int len, int start, int want) {
  final left = len - start;
  if (left <= 0) return 0;
  return left < want ? left : want;
}

/// Back-camera rotation for ML Kit (same formula as Google's ML Kit example).
int rotationFor(int sensorOrientation, int deviceDegrees) =>
    (sensorOrientation - deviceDegrees + 360) % 360;

// ------------------------------------------------------------------
// Reading area (crop), sharpness and brightness
// ------------------------------------------------------------------

/// A rectangle in camera-buffer pixels. All values are even (NV21 needs it).
class CropRect {
  final int left;
  final int top;
  final int width;
  final int height;
  const CropRect(this.left, this.top, this.width, this.height);

  @override
  String toString() => 'CropRect($left,$top,$width,$height)';
}

int _even(int v) => v - v % 2;

/// The centre "reading band" in buffer coordinates.
/// [bandW] / [bandH] are fractions of the picture as seen upright on screen.
/// [rotation] is the rotation (0/90/180/270) needed to show the buffer upright.
CropRect bandFor(int bufW, int bufH, int rotation, double bandW, double bandH) {
  final w0 = _even(bufW), h0 = _even(bufH);
  final sideways = rotation % 180 != 0;
  final fw = (sideways ? bandH : bandW).clamp(0.05, 1.0).toDouble();
  final fh = (sideways ? bandW : bandH).clamp(0.05, 1.0).toDouble();
  var w = _even((w0 * fw).round());
  var h = _even((h0 * fh).round());
  if (w < 2) w = 2;
  if (h < 2) h = 2;
  if (w > w0) w = w0;
  if (h > h0) h = h0;
  final l = _even((w0 - w) ~/ 2);
  final t = _even((h0 - h) ~/ 2);
  return CropRect(l, t, w, h);
}

/// Cuts [r] out of a tight NV21 frame.
Nv21Frame cropNv21(Nv21Frame f, CropRect r) {
  if (r.left == 0 && r.top == 0 && r.width == f.width && r.height == f.height) return f;
  final out = Uint8List(r.width * r.height + (r.width * r.height) ~/ 2);
  var idx = 0;
  for (var row = r.top; row < r.top + r.height; row++) {
    final src = row * f.width + r.left;
    out.setRange(idx, idx + r.width, f.bytes, src);
    idx += r.width;
  }
  final uvBase = f.width * f.height;
  for (var row = 0; row < r.height ~/ 2; row++) {
    final src = uvBase + (r.top ~/ 2 + row) * f.width + r.left;
    out.setRange(idx, idx + r.width, f.bytes, src);
    idx += r.width;
  }
  return Nv21Frame(out, r.width, r.height);
}

/// How sharp the luma inside [r] is (bigger = sharper).
/// Scans every [rowStep]-th row across its full width and adds up how much
/// each pixel differs from its right and lower neighbour (squared, so one
/// crisp edge counts far more than a smeared one). Motion blur on a moving
/// bike smears exactly these edges.
double sharpness(Uint8List y, int stride, CropRect r, {int rowStep = 4}) {
  var sum = 0;
  var n = 0;
  final colEnd = r.left + r.width - 1;
  for (var row = r.top; row < r.top + r.height - 1; row += rowStep) {
    final base = row * stride;
    if (base + stride + colEnd >= y.length) break;
    for (var i = base + r.left; i < base + colEnd; i++) {
      final dx = y[i + 1] - y[i];
      final dy = y[i + stride] - y[i];
      sum += dx * dx + dy * dy;
      n++;
    }
  }
  return n == 0 ? 0 : sum / n;
}

/// Average brightness (0..255) of the luma inside [r].
double meanLuma(Uint8List y, int stride, CropRect r, {int step = 8}) {
  var sum = 0;
  var n = 0;
  for (var row = r.top; row < r.top + r.height; row += step) {
    final base = row * stride;
    for (var col = r.left; col < r.left + r.width; col += step) {
      final i = base + col;
      if (i >= y.length) break;
      sum += y[i];
      n++;
    }
  }
  return n == 0 ? 0 : sum / n;
}

// ------------------------------------------------------------------
// Fixed-shutter brightness control
// ------------------------------------------------------------------

class ExposureSetting {
  final int exposureNs;
  final int iso;
  const ExposureSetting(this.exposureNs, this.iso);

  @override
  bool operator ==(Object other) =>
      other is ExposureSetting && other.exposureNs == exposureNs && other.iso == iso;

  @override
  int get hashCode => Object.hash(exposureNs, iso);

  @override
  String toString() => 'ExposureSetting(${exposureNs}ns, ISO $iso)';
}

/// Keeps the shutter fast ([targetNs]) and moves ISO to get the right brightness.
/// Only if ISO is already at max does the shutter get slower, never slower than
/// [slowestNs]. In very bright light the shutter gets even faster.
/// Returns null when the picture is already bright enough (no change needed).
ExposureSetting? nextExposure({
  required double meanY,
  required ExposureSetting current,
  required int targetNs,
  required int slowestNs,
  required int minNs,
  required int maxNs,
  required int minIso,
  required int maxIso,
  double targetY = 115,
  double deadband = 0.12,
}) {
  final measured = meanY < 4 ? 4.0 : meanY;
  var ratio = targetY / measured;
  final shutterOff = current.exposureNs > targetNs * 1.05 || current.exposureNs < targetNs * 0.95;
  if ((ratio - 1).abs() < deadband && !shutterOff) return null;
  if (ratio > 2) ratio = 2;
  if (ratio < 0.5) ratio = 0.5;
  final wanted = current.exposureNs.toDouble() * current.iso * ratio; // "light amount"

  var hiNs = slowestNs < maxNs ? slowestNs : maxNs;
  if (hiNs < minNs) hiNs = minNs;
  var ns = targetNs.clamp(minNs, hiNs).toDouble();
  var iso = wanted / ns;
  if (iso > maxIso) {
    iso = maxIso.toDouble();
    ns = (wanted / iso).clamp(minNs.toDouble(), hiNs.toDouble()).toDouble();
  } else if (iso < minIso) {
    iso = minIso.toDouble();
    ns = (wanted / iso).clamp(minNs.toDouble(), hiNs.toDouble()).toDouble();
  }
  final next = ExposureSetting(ns.round(), iso.round().clamp(minIso, maxIso).toInt());
  return next == current ? null : next;
}

// ------------------------------------------------------------------
// Multi-frame voting: fixes single wrong letters across several reads
// ------------------------------------------------------------------

class PlateVoter {
  final int windowMs;
  final int maxDiff;
  final List<(String, int)> _reads = [];
  PlateVoter({this.windowMs = 2500, this.maxDiff = 2});

  static int _diff(String a, String b) {
    var d = 0;
    for (var i = 0; i < a.length; i++) {
      if (a.codeUnitAt(i) != b.codeUnitAt(i)) d++;
    }
    return d;
  }

  /// Adds new reads and returns plates agreed by a clear majority
  /// (at least 3 reads, and every letter has more than half the votes).
  Set<String> add(Iterable<String> plates, int nowMs) {
    _reads.removeWhere((r) => nowMs - r.$2 > windowMs);
    for (final p in plates) {
      _reads.add((p, nowMs));
    }
    final out = <String>{};
    final used = List<bool>.filled(_reads.length, false);
    for (var i = 0; i < _reads.length; i++) {
      if (used[i]) continue;
      final seed = _reads[i].$1;
      final group = <String>[seed];
      used[i] = true;
      for (var j = i + 1; j < _reads.length; j++) {
        if (used[j]) continue;
        final other = _reads[j].$1;
        if (other.length == seed.length && _diff(seed, other) <= maxDiff) {
          group.add(other);
          used[j] = true;
        }
      }
      if (group.length < 3) continue;
      final sb = StringBuffer();
      var ok = true;
      for (var k = 0; k < seed.length && ok; k++) {
        final counts = <int, int>{};
        for (final g in group) {
          final c = g.codeUnitAt(k);
          counts[c] = (counts[c] ?? 0) + 1;
        }
        final best = counts.entries.reduce((a, b) => a.value >= b.value ? a : b);
        if (best.value * 2 <= group.length) {
          ok = false;
        } else {
          sb.writeCharCode(best.key);
        }
      }
      if (ok) out.add(sb.toString());
    }
    return out;
  }

  void clear() => _reads.clear();
}

// ------------------------------------------------------------------
// Plate rules
// ------------------------------------------------------------------
class PlateReader {
  static final _normal = RegExp(r'^[A-Z]{2}[0-9]{1,2}[A-Z]{0,3}[0-9]{4}$');
  static final _bh = RegExp(r'^[0-9]{2}BH[0-9]{4}[A-Z]{1,2}$');
  static const _toLetter = {'0': 'O', '1': 'I', '2': 'Z', '5': 'S', '6': 'G', '8': 'B'};
  static const _toDigit = {
    'O': '0', 'Q': '0', 'D': '0', 'U': '0', 'I': '1', 'L': '1', 'J': '1',
    'Z': '2', 'S': '5', 'G': '6', 'B': '8',
  };

  // Real Indian state / UT codes. A plate must start with one of these.
  static const states = {
    'AN', 'AP', 'AR', 'AS', 'BR', 'CG', 'CH', 'DD', 'DL', 'DN', 'GA', 'GJ',
    'HP', 'HR', 'JH', 'JK', 'KA', 'KL', 'LA', 'LD', 'MH', 'ML', 'MN', 'MP',
    'MZ', 'NL', 'OD', 'OR', 'PB', 'PY', 'RJ', 'SK', 'TG', 'TN', 'TR', 'TS',
    'UK', 'UP', 'WB',
  };

  static String clean(String s) =>
      s.toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]'), '');

  static String? fix(String s) {
    if (_bh.hasMatch(s)) return s;
    if (s.length < 8 || s.length > 10) return null;
    final c = s.split('');
    final n = c.length;
    for (var i = 0; i < 2; i++) {
      c[i] = _toLetter[c[i]] ?? c[i];
    }
    for (var i = 2; i < 4; i++) {
      c[i] = _toDigit[c[i]] ?? c[i];
    }
    for (var i = 4; i < n - 4; i++) {
      c[i] = _toLetter[c[i]] ?? c[i];
    }
    for (var i = n - 4; i < n; i++) {
      c[i] = _toDigit[c[i]] ?? c[i];
    }
    final out = c.join();
    if (!states.contains(out.substring(0, 2))) return null;
    return _normal.hasMatch(out) ? out : null;
  }

  /// Cleans raw text pieces (whole text, blocks, lines).
  static List<String> pieces(Iterable<String> raw) =>
      raw.map(clean).where((s) => s.length >= 4).toList();

  /// Plate-shaped strings found in the text.
  static Set<String> plates(List<String> cleaned) {
    final found = <String>{};
    for (final s in cleaned) {
      if (s.length < 8) continue;
      final maxLen = s.length < 10 ? s.length : 10;
      for (var len = maxLen; len >= 8; len--) {
        final hits = <String>{};
        for (var i = 0; i + len <= s.length; i++) {
          final p = fix(s.substring(i, i + len));
          if (p != null) hits.add(p);
        }
        if (hits.isNotEmpty) {
          found.addAll(hits);
          break;
        }
      }
    }
    return found;
  }

  /// List plates found in the text (plate rule OR loose text match).
  static Set<String> listHits(List<String> cleaned, Set<String> plates, Set<String> list) {
    final hits = <String>{};
    for (final l in list) {
      if (plates.contains(l)) {
        hits.add(l);
        continue;
      }
      final lf = _digitsFixed(l);
      for (final s in cleaned) {
        if (s.contains(l) || _digitsFixed(s).contains(lf)) {
          hits.add(l);
          break;
        }
      }
    }
    return hits;
  }

  static String _digitsFixed(String s) =>
      s.split('').map((ch) => _toDigit[ch] ?? ch).join();
}

// ------------------------------------------------------------------
// v5: list import, full-screen band, match photo, spoken plate
// ------------------------------------------------------------------

class ImportResult {
  final Set<String> plates;
  final int cells;
  const ImportResult(this.plates, this.cells);
}

/// Finds every number plate among the cells of a spreadsheet / CSV,
/// whatever column it is in. Names, loan numbers and amounts are ignored.
ImportResult importPlates(Iterable<String> cells) {
  final out = <String>{};
  var n = 0;
  for (final cell in cells) {
    n++;
    final c = PlateReader.clean(cell);
    if (c.length < 8 || c.length > 10) continue;
    final p = PlateReader.fix(c);
    if (p != null) out.add(p);
  }
  return ImportResult(out, n);
}

/// The camera picture fills the screen and its edges get cut off ("cover").
/// Turns a band given as a fraction of the SCREEN into a fraction of the
/// upright CAMERA PICTURE, so the band you see is exactly what gets read.
/// Aspects are width / height.
(double, double) bandOfImage(double imageAspect, double screenAspect, double bandW, double bandH) {
  var visW = 1.0, visH = 1.0;
  if (screenAspect > imageAspect) {
    visH = imageAspect / screenAspect; // picture is cut at top and bottom
  } else {
    visW = screenAspect / imageAspect; // picture is cut at the sides
  }
  return ((bandW * visW).clamp(0.05, 1.0).toDouble(), (bandH * visH).clamp(0.05, 1.0).toDouble());
}

/// NV21 frame -> RGBA pixels (for the match photo). [step] = 2 makes it half size.
(Uint8List, int, int) nv21ToRgba(Nv21Frame f, {int step = 2}) {
  final ow = f.width ~/ step, oh = f.height ~/ step;
  final out = Uint8List(ow * oh * 4);
  final b = f.bytes;
  final uvBase = f.width * f.height;
  var o = 0;
  for (var y = 0; y < oh; y++) {
    final sy = y * step;
    final uvRow = uvBase + (sy >> 1) * f.width;
    for (var x = 0; x < ow; x++) {
      final sx = x * step;
      final yy = b[sy * f.width + sx];
      final uvi = uvRow + (sx & ~1);
      final v = b[uvi] - 128;
      final u = b[uvi + 1] - 128;
      var r = (yy + 1.402 * v).round();
      var g = (yy - 0.344 * u - 0.714 * v).round();
      var bl = (yy + 1.772 * u).round();
      out[o++] = r < 0 ? 0 : (r > 255 ? 255 : r);
      out[o++] = g < 0 ? 0 : (g > 255 ? 255 : g);
      out[o++] = bl < 0 ? 0 : (bl > 255 ? 255 : bl);
      out[o++] = 255;
    }
  }
  return (out, ow, oh);
}

/// "MH46DF1352" -> "M H, 4 6, D F, 1 3 5 2" so the phone voice reads it clearly.
String spokenPlate(String plate) {
  final groups = <String>[];
  var cur = StringBuffer();
  bool? curDigit;
  for (final ch in plate.split('')) {
    final d = ch.codeUnitAt(0) >= 48 && ch.codeUnitAt(0) <= 57;
    if (curDigit != null && d != curDigit) {
      groups.add(cur.toString().trim());
      cur = StringBuffer();
    }
    curDigit = d;
    cur.write('$ch ');
  }
  if (cur.isNotEmpty) groups.add(cur.toString().trim());
  return groups.join(', ');
}

/// "MH46DF1352" -> "MH 46 DF 1352" for showing on screen.
String prettyPlate(String plate) => spokenPlate(plate).replaceAll(' ', '').replaceAll(',', ' ');

// ------------------------------------------------------------------
// Test helpers: build the different frame layouts real phones produce.
// ------------------------------------------------------------------
class TestFrames {
  /// y: w*h, u/v: (w/2)*(h/2). Returns name -> planes.
  static Map<String, List<PlaneData>> layouts(
      int w, int h, Uint8List y, Uint8List u, Uint8List v) {
    final cw = w ~/ 2, ch = h ~/ 2;
    final res = <String, List<PlaneData>>{};

    // A: one plane, tight NV21
    final a = Uint8List(w * h + w * h ~/ 2);
    a.setRange(0, w * h, y);
    var k = w * h;
    for (var i = 0; i < cw * ch; i++) {
      a[k++] = v[i];
      a[k++] = u[i];
    }
    res['1 plane tight'] = [PlaneData(a, w)];

    // B: one plane NV21, padded rows (like many Samsung phones)
    const pad = 64;
    final s = w + pad;
    final b = Uint8List(s * h + s * ch);
    for (var r = 0; r < h; r++) {
      b.setRange(r * s, r * s + w, y, r * w);
    }
    for (var r = 0; r < ch; r++) {
      for (var c = 0; c < cw; c++) {
        b[s * h + r * s + 2 * c] = v[r * cw + c];
        b[s * h + r * s + 2 * c + 1] = u[r * cw + c];
      }
    }
    res['1 plane padded'] = [PlaneData(b, s)];

    // C: three planes, padded, pixelStride 2 (CameraX YUV_420_888 from NV21)
    final yp = Uint8List(s * (h - 1) + w);
    for (var r = 0; r < h; r++) {
      yp.setRange(r * s, r * s + w, y, r * w);
    }
    final vu = Uint8List(s * ch);
    for (var r = 0; r < ch; r++) {
      for (var c = 0; c < cw; c++) {
        vu[r * s + 2 * c] = v[r * cw + c];
        vu[r * s + 2 * c + 1] = u[r * cw + c];
      }
    }
    final vLen = s * (ch - 1) + 2 * (cw - 1) + 1;
    res['3 planes stride 2'] = [
      PlaneData(yp, s, 1),
      PlaneData(Uint8List.sublistView(vu, 1, 1 + vLen), s, 2),
      PlaneData(Uint8List.sublistView(vu, 0, vLen), s, 2),
    ];

    // D: three planes, I420 (pixelStride 1), padded
    final cs = cw + 32;
    final up = Uint8List(cs * ch), vp = Uint8List(cs * ch);
    for (var r = 0; r < ch; r++) {
      up.setRange(r * cs, r * cs + cw, u, r * cw);
      vp.setRange(r * cs, r * cs + cw, v, r * cw);
    }
    res['3 planes stride 1'] = [
      PlaneData(yp, s, 1),
      PlaneData(up, cs, 1),
      PlaneData(vp, cs, 1),
    ];
    return res;
  }

  /// Tight reference NV21 for comparison.
  static Uint8List reference(int w, int h, Uint8List y, Uint8List u, Uint8List v) {
    final a = Uint8List(w * h + w * h ~/ 2);
    a.setRange(0, w * h, y);
    var k = w * h;
    for (var i = 0; i < (w ~/ 2) * (h ~/ 2); i++) {
      a[k++] = v[i];
      a[k++] = u[i];
    }
    return a;
  }

  /// RGBA -> Y, U, V (BT.601), chroma subsampled 2x2.
  static (Uint8List, Uint8List, Uint8List) rgbaToYuv(Uint8List rgba, int w, int h) {
    final y = Uint8List(w * h);
    final u = Uint8List((w ~/ 2) * (h ~/ 2));
    final v = Uint8List((w ~/ 2) * (h ~/ 2));
    for (var r = 0; r < h; r++) {
      for (var c = 0; c < w; c++) {
        final i = (r * w + c) * 4;
        final R = rgba[i], G = rgba[i + 1], B = rgba[i + 2];
        y[r * w + c] = (0.299 * R + 0.587 * G + 0.114 * B).round().clamp(0, 255);
        if (r % 2 == 0 && c % 2 == 0) {
          final j = (r ~/ 2) * (w ~/ 2) + (c ~/ 2);
          u[j] = (-0.169 * R - 0.331 * G + 0.5 * B + 128).round().clamp(0, 255);
          v[j] = (0.5 * R - 0.419 * G - 0.081 * B + 128).round().clamp(0, 255);
        }
      }
    }
    return (y, u, v);
  }
}
