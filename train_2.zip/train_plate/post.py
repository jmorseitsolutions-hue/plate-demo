"""Model output -> plate boxes, and scoring. Only numpy / OpenCV (used in training AND on the phone side tests)."""
import cv2
import numpy as np

from data import STRIDE


def sigmoid(x):
    return 1 / (1 + np.exp(-x))


def mask_to_boxes(logits, thr=0.5, stride=STRIDE, min_cells=2):
    """logits: (G, G) -> [(x, y, w, h, score)] in input pixels."""
    p = sigmoid(logits.astype(np.float32))
    binary = (p > thr).astype(np.uint8)
    n, labels, stats, _ = cv2.connectedComponentsWithStats(binary, connectivity=8)
    out = []
    for i in range(1, n):
        x, y, w, h, area = stats[i]
        if area < min_cells:
            continue
        score = float(p[labels == i].mean())
        ar = w / max(h, 1)
        if ar > 12 or ar < 0.4:
            continue
        out.append((float(x * stride), float(y * stride), float(w * stride), float(h * stride), score))
    return out


def iou(a, b):
    ax0, ay0, aw, ah = a[:4]
    bx0, by0, bw, bh = b[:4]
    ix = max(0.0, min(ax0 + aw, bx0 + bw) - max(ax0, bx0))
    iy = max(0.0, min(ay0 + ah, by0 + bh) - max(ay0, by0))
    inter = ix * iy
    u = aw * ah + bw * bh - inter
    return inter / u if u > 0 else 0.0


def hit(pred, gt, grow=0.25):
    """Plate centre inside the (slightly grown) predicted box = good enough to crop and read it."""
    px, py, pw, ph = pred[:4]
    gx, gy = gt[0] + gt[2] / 2, gt[1] + gt[3] / 2
    return (px - pw * grow <= gx <= px + pw * (1 + grow)) and (py - ph * grow <= gy <= py + ph * (1 + grow))


def score_image(preds, gts, iou_thr=0.3):
    """Returns counts: (tp, fp, fn) using 'hit' OR IoU matching, greedy by score."""
    used = set()
    tp = 0
    for p in sorted(preds, key=lambda b: -b[4]):
        best, bi = 0.0, -1
        for i, g in enumerate(gts):
            if i in used:
                continue
            v = iou(p, g)
            if hit(p, g):
                v = max(v, iou_thr)
            if v > best:
                best, bi = v, i
        if bi >= 0 and best >= iou_thr:
            used.add(bi)
            tp += 1
    fp = len(preds) - tp
    fn = len(gts) - tp
    return tp, fp, fn


def prf(tp, fp, fn):
    p = tp / (tp + fp) if tp + fp else 0.0
    r = tp / (tp + fn) if tp + fn else 0.0
    f = 2 * p * r / (p + r) if p + r else 0.0
    return p, r, f
