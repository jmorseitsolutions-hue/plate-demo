"""PlateNet: finds number plates. MobileNetV3-Small (torchvision, BSD licence) + a small FPN head.

Input : (N, 3, 384, 384) RGB, values 0..255 (the app sends plain pixels; scaling is inside).
Output: (N, 1, 96, 96) plate-score logits (one cell = 4x4 input pixels).
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision.models import MobileNet_V3_Small_Weights, mobilenet_v3_small

TAPS = (1, 3, 8, 12)          # feature blocks at strides 4, 8, 16, 32
TAP_CHANNELS = (16, 24, 48, 576)


class PlateNet(nn.Module):
    def __init__(self, pretrained=True):
        super().__init__()
        weights = MobileNet_V3_Small_Weights.IMAGENET1K_V1 if pretrained else None
        self.features = mobilenet_v3_small(weights=weights).features[: TAPS[-1] + 1]
        self.lat = nn.ModuleList([nn.Conv2d(c, 64, 1) for c in TAP_CHANNELS])
        self.head = nn.Sequential(
            nn.Conv2d(64, 64, 3, padding=1, bias=False), nn.BatchNorm2d(64), nn.ReLU(inplace=True),
            nn.Conv2d(64, 32, 3, padding=1, bias=False), nn.BatchNorm2d(32), nn.ReLU(inplace=True),
            nn.Conv2d(32, 1, 1),
        )
        nn.init.constant_(self.head[-1].bias, -4.0)  # start by saying "no plate" everywhere
        self.register_buffer('mean', torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1) * 255.0)
        self.register_buffer('std', torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1) * 255.0)

    def forward(self, x):
        x = (x - self.mean) / self.std
        feats = []
        for i, block in enumerate(self.features):
            x = block(x)
            if i in TAPS:
                feats.append(x)
        y = self.lat[-1](feats[-1])
        for j in range(len(feats) - 2, -1, -1):
            f = feats[j]
            y = F.interpolate(y, size=(f.shape[-2], f.shape[-1]), mode='nearest') + self.lat[j](f)
        return self.head(y)


def loss_fn(logits, target, pos_weight=4.0):
    bce = F.binary_cross_entropy_with_logits(
        logits, target, pos_weight=torch.tensor(pos_weight, device=logits.device))
    p = torch.sigmoid(logits)
    inter = (p * target).sum(dim=(1, 2, 3))
    denom = p.sum(dim=(1, 2, 3)) + target.sum(dim=(1, 2, 3))
    dice = 1 - (2 * inter + 1.0) / (denom + 1.0)
    return bce + dice.mean()
