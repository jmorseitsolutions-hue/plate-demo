"""Draws realistic Indian number plates (HSRP style) and fits them into photos.

Only numpy / OpenCV / Pillow, so it runs anywhere. Used to teach the model what
Indian plates look like, on top of the real (mostly foreign) plate photos.
"""
import os
import random

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

STATES = ('AN AP AR AS BR CG CH DD DL DN GA GJ HP HR JH JK KA KL LA LD MH ML MN MP MZ NL OD '
          'OR PB PY RJ SK TG TN TR TS UK UP WB').split()
LETTERS = 'ABCDEFGHJKLMNPRSTUVWXYZ'

_FONT_CANDIDATES = [
    '/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed-Bold.ttf',
    '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
    '/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf',
]


def _font(size):
    for f in _FONT_CANDIDATES:
        if os.path.exists(f):
            return ImageFont.truetype(f, size)
    return ImageFont.load_default()


def random_plate_text(rng):
    if rng.random() < 0.06:  # BH series: 22BH1234AA
        return f"{rng.randint(21, 26)}BH{rng.randint(0, 9999):04d}{''.join(rng.choice(LETTERS) for _ in range(rng.choice((1, 2))))}"
    state = rng.choice(STATES)
    series = ''.join(rng.choice(LETTERS) for _ in range(rng.choice((1, 2, 2, 2, 3))))
    return f"{state}{rng.randint(1, 99):02d}{series}{rng.randint(1, 9999):04d}"


def _split(text):
    """MH46DF1352 -> ['MH', '46', 'DF', '1352']"""
    out, cur = [], ''
    for ch in text:
        if cur and ch.isdigit() != cur[-1].isdigit():
            out.append(cur)
            cur = ''
        cur += ch
    out.append(cur)
    return out


def render_plate(rng, text=None, two_rows=None):
    """Returns an RGB numpy plate image (rectangular, flat), its text, and whether it has two rows."""
    text = text or random_plate_text(rng)
    if two_rows is None:
        two_rows = rng.random() < 0.2
    kind = rng.random()
    if kind < 0.8:
        bg, fg = (245, 245, 240), (15, 15, 15)  # private: white
    elif kind < 0.93:
        bg, fg = (245, 205, 30), (15, 15, 15)  # commercial: yellow
    else:
        bg, fg = (20, 120, 60), (245, 245, 245)  # EV: green
    W, H = (340, 200) if two_rows else (500, 120)
    img = Image.new('RGB', (W, H), bg)
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([3, 3, W - 4, H - 4], radius=10, outline=fg, width=5)
    # HSRP blue IND strip with a small round hologram
    strip = 34 if not two_rows else 30
    if rng.random() < 0.85:
        d.rectangle([8, 8, 8 + strip, H - 9], fill=(20, 60, 160))
        cx = 8 + strip // 2
        d.ellipse([cx - 9, 14, cx + 9, 32], outline=(200, 200, 230), width=2)
        f_small = _font(14)
        for i, ch in enumerate('IND'):
            d.text((cx - 5, H - 58 + i * 15), ch, font=f_small, fill=(245, 245, 245))
    x0 = 8 + strip + 6
    parts = _split(text)
    rows = [' '.join(parts[:2]), ' '.join(parts[2:])] if two_rows else [' '.join(parts)]
    avail_w, avail_h = W - x0 - 12, H - 16
    row_h = avail_h // len(rows)
    for r, row in enumerate(rows):
        size = int(row_h * 0.95)
        f = _font(size)
        bbox = d.textbbox((0, 0), row, font=f)
        tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
        layer = Image.new('RGBA', (tw + 4, th + 4), (0, 0, 0, 0))
        ImageDraw.Draw(layer).text((2 - bbox[0], 2 - bbox[1]), row, font=f, fill=fg + (255,))
        layer = layer.resize((min(avail_w, int(tw * rng.uniform(0.95, 1.1))), int(row_h * 0.82)))
        px = x0 + (avail_w - layer.width) // 2
        py = 8 + r * row_h + (row_h - layer.height) // 2
        img.paste(layer, (px, py), layer)
    a = np.asarray(img).astype(np.float32)
    # dirt, wear and uneven light
    if rng.random() < 0.6:
        noise = np.random.default_rng(rng.randint(0, 1 << 30)).normal(0, rng.uniform(3, 14), a.shape[:2])
        a += noise[..., None]
    if rng.random() < 0.5:
        g = np.linspace(rng.uniform(0.7, 1.0), rng.uniform(0.85, 1.1), W)[None, :, None]
        a *= g
    return np.clip(a, 0, 255).astype(np.uint8), text, two_rows


def paste_plate(rng, image, box, plate=None):
    """Draws an Indian plate into image (H x W x 3 RGB uint8) inside box (x, y, w, h).

    The plate is warped with a little perspective and matched to the local light.
    Returns the new image and the plate's tight box (x, y, w, h).
    """
    x, y, w, h = [float(v) for v in box]
    if w < 6 or h < 3:
        return image, box
    if plate is None:
        # wide slot -> one-row plate, squarish slot -> two-row plate
        plate = render_plate(rng, two_rows=(w / h) < 2.6)[0]
    ph, pw = plate.shape[:2]
    # keep the plate's own shape and fully COVER the old plate (no old plate left visible)
    target_ar = pw / ph
    if w / h > target_ar:
        nw, nh = w, w / target_ar
    else:
        nw, nh = h * target_ar, h
    nw *= rng.uniform(1.04, 1.12)
    nh *= rng.uniform(1.04, 1.12)
    cx, cy = x + w / 2, y + h / 2
    j = lambda s: rng.uniform(-s, s)
    js = 0.06
    dst = np.float32([
        [cx - nw / 2 + j(nw * js), cy - nh / 2 + j(nh * js)],
        [cx + nw / 2 + j(nw * js), cy - nh / 2 + j(nh * js)],
        [cx + nw / 2 + j(nw * js), cy + nh / 2 + j(nh * js)],
        [cx - nw / 2 + j(nw * js), cy + nh / 2 + j(nh * js)],
    ])
    src = np.float32([[0, 0], [pw, 0], [pw, ph], [0, ph]])
    H, W = image.shape[:2]
    xs, ys = dst[:, 0], dst[:, 1]
    bx0, by0 = int(max(0, np.floor(xs.min()))), int(max(0, np.floor(ys.min())))
    bx1, by1 = int(min(W, np.ceil(xs.max()))), int(min(H, np.ceil(ys.max())))
    if bx1 - bx0 < 4 or by1 - by0 < 3:
        return image, box
    # warp only inside the plate's own area (fast even on big photos)
    roi_dst = dst - np.float32([bx0, by0])
    M = cv2.getPerspectiveTransform(src, roi_dst)
    rw, rh = bx1 - bx0, by1 - by0
    warped_roi = cv2.warpPerspective(plate, M, (rw, rh), flags=cv2.INTER_AREA)
    mask_roi = cv2.warpPerspective(np.full((ph, pw), 255, np.uint8), M, (rw, rh), flags=cv2.INTER_LINEAR)
    # match the brightness of what was there before
    region = image[by0:by1, bx0:bx1].astype(np.float32)
    local = region.mean() if region.size else 128.0
    gain = np.clip(local / max(warped_roi.mean(), 1.0) * rng.uniform(0.9, 1.4), 0.35, 1.3)
    warped_roi = np.clip(warped_roi.astype(np.float32) * gain, 0, 255)
    m = (mask_roi.astype(np.float32) / 255.0)[..., None]
    blended = region * (1 - m) + warped_roi * m
    # slight blur so the plate sits in the photo naturally
    if rng.random() < 0.5:
        k = rng.choice((3, 5))
        blended = cv2.GaussianBlur(blended, (k, k), 0)
    out = image.copy()
    out[by0:by1, bx0:bx1] = np.clip(blended, 0, 255).astype(np.uint8)
    return out, (bx0, by0, bx1 - bx0, by1 - by0)
