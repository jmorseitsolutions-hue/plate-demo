#!/usr/bin/env bash
# Runs one build step. If it fails, the real error lines are posted as GitHub
# annotations, which are visible on the public run page (logs are not).
# Usage: bash ci/step.sh "Step name" command args...
set -u -o pipefail
name="$1"; shift
log=$(mktemp)
"$@" 2>&1 | tee "$log"
rc=${PIPESTATUS[0]}
if [ "$rc" -ne 0 ]; then
  {
    grep -E -A3 "What went wrong" "$log"
    grep -E "error •|error:|Error:|ERROR:|FAILURE|e: file|Expected:|Actual:|Exception|version solving failed|depends on|Could not|cannot find symbol|isn't defined|Undefined|The method|The getter|Test failed|Some tests failed|\[E\]" "$log"
  } | grep -v -E "^\s*$|^--$" | awk '!seen[$0]++' | head -14 | while IFS= read -r line; do
    clean=$(printf '%s' "$line" | sed -e 's/%/%25/g' -e 's/\r//g' | cut -c1-500)
    echo "::error title=$name::$clean"
  done
  echo "::error title=$name::step failed (exit code $rc)"
fi
rm -f "$log"
exit "$rc"
