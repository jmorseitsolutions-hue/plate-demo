"""Plate photos -> training samples. Only numpy / OpenCV / Pillow (testable anywhere)."""
import io
import json
import os
import random
import zipfile

import cv2
import numpy as np
from PIL import Image

from synth import paste_plate

SIZE = 384      # model input (square, letterboxed like the app does)
STRIDE = 4      # output mask is SIZE / STRIDE = 96 cells
PAD = 114


def extract_coco_zip(zip_path, out_dir):
    """Unzips a Roboflow COCO export and returns [(image_path, [boxes xywh]), ...]."""
    os.makedirs(out_dir, exist_ok=True)
    with zipfile.ZipFile(zip_path) as z:
        names = z.namelist()
        jsons = [n for n in names if n.endswith('.json')]
        items = []
        for jn in jsons:
            data = json.loads(z.read(jn))
            if not isinstance(data, dict) or 'annotations' not in data or 'images' not in data:
                continue
            by_base = {os.path.basename(n): n for n in names if not n.endswith('/')}
            boxes = {}
            for a in data['annotations']:
                bb = a.get('bbox')
                if bb and bb[2] > 1 and bb[3] > 1:
                    boxes.setdefault(a['image_id'], []).append([float(v) for v in bb])
            for im in data['images']:
                src = by_base.get(os.path.basename(im['file_name']))
                if src is None:
                    continue
                dst = os.path.join(out_dir, os.path.basename(src))
                if not os.path.exists(dst):
                    with open(dst, 'wb') as f:
                        f.write(z.read(src))
                items.append((dst, boxes.get(im['id'], [])))
    return items


def load_rgb(path):
    img = cv2.imread(path, cv2.IMREAD_COLOR)
    if img is None:
        img = np.asarray(Image.open(path).convert('RGB'))[:, :, ::-1]
    return cv2.cvtColor(img, cv2.COLOR_BGR2RGB)


def letterbox(img, size=SIZE):
    """Fit into size x size keeping shape (the app does exactly the same). Returns img, scale, (dx, dy)."""
    h, w = img.shape[:2]
    s = size / max(h, w)
    nw, nh = max(1, round(w * s)), max(1, round(h * s))
    resized = cv2.resize(img, (nw, nh), interpolation=cv2.INTER_AREA if s < 1 else cv2.INTER_LINEAR)
    out = np.full((size, size, 3), PAD, np.uint8)
    dx, dy = (size - nw) // 2, (size - nh) // 2
    out[dy:dy + nh, dx:dx + nw] = resized
    return out, s, (dx, dy)


def boxes_to_mask(boxes, size=SIZE, stride=STRIDE):
    """Filled rectangles on the output grid. Tiny plates still mark at least their centre cell."""
    g = size // stride
    m = np.zeros((g, g), np.float32)
    for x, y, w, h in boxes:
        x0, y0 = int(np.floor(x / stride)), int(np.floor(y / stride))
        x1, y1 = int(np.ceil((x + w) / stride)), int(np.ceil((y + h) / stride))
        x0, y0, x1, y1 = max(0, x0), max(0, y0), min(g, x1), min(g, y1)
        if x1 <= x0 or y1 <= y0:
            cx, cy = int((x + w / 2) / stride), int((y + h / 2) / stride)
            if 0 <= cx < g and 0 <= cy < g:
                m[cy, cx] = 1
            continue
        m[y0:y1, x0:x1] = 1
    return m


def _crop(img, boxes, x0, y0, x1, y1):
    crop = img[y0:y1, x0:x1]
    out = []
    for x, y, w, h in boxes:
        bx0, by0 = max(x, x0), max(y, y0)
        bx1, by1 = min(x + w, x1), min(y + h, y1)
        if bx1 - bx0 >= 0.6 * w and by1 - by0 >= 0.6 * h:  # keep plates that are mostly inside
            out.append([bx0 - x0, by0 - y0, bx1 - bx0, by1 - by0])
    return crop, out


def _photometric(img, rng):
    a = img.astype(np.float32)
    a = a * rng.uniform(0.6, 1.35) + rng.uniform(-30, 30)                 # brightness / contrast
    if rng.random() < 0.5:
        a = 255 * (np.clip(a, 0, 255) / 255) ** rng.uniform(0.7, 1.5)    # gamma (shade / sun)
    if rng.random() < 0.4:
        a *= np.array([rng.uniform(0.85, 1.15) for _ in range(3)], np.float32)  # colour cast
    img = np.clip(a, 0, 255).astype(np.uint8)
    r = rng.random()
    if r < 0.35:   # motion blur, mostly sideways like a moving bike
        k = rng.choice((5, 7, 9, 11, 15))
        ker = np.zeros((k, k), np.float32)
        ang = rng.uniform(-20, 20)
        ker[k // 2, :] = 1
        M = cv2.getRotationMatrix2D((k / 2 - 0.5, k / 2 - 0.5), ang, 1)
        ker = cv2.warpAffine(ker, M, (k, k))
        ker /= max(ker.sum(), 1e-6)
        img = cv2.filter2D(img, -1, ker)
    elif r < 0.55:
        img = cv2.GaussianBlur(img, (rng.choice((3, 5)),) * 2, 0)
    if rng.random() < 0.4:
        n = np.random.default_rng(rng.randint(0, 1 << 30)).normal(0, rng.uniform(3, 12), img.shape)
        img = np.clip(img.astype(np.float32) + n, 0, 255).astype(np.uint8)
    if rng.random() < 0.5:
        q = rng.randint(35, 90)
        ok, enc = cv2.imencode('.jpg', img, [cv2.IMWRITE_JPEG_QUALITY, q])
        if ok:
            img = cv2.imdecode(enc, cv2.IMREAD_UNCHANGED)
    return img


def make_sample(img, boxes, rng, train=True, synth_prob=0.5):
    """One training sample: (384x384x3 uint8, 96x96 mask, boxes in input pixels)."""
    boxes = [list(b) for b in boxes]
    if train and boxes and rng.random() < synth_prob:
        new = []
        for b in boxes:
            img, nb = paste_plate(rng, img, b)
            new.append(list(nb))
        boxes = new
    H, W = img.shape[:2]
    if train:
        r = rng.random()
        if boxes and r < 0.7:
            # crop around one plate so plates appear at many sizes and positions
            x, y, w, h = rng.choice(boxes)
            frac = rng.uniform(0.04, 0.6)             # plate width as a share of the crop width
            cw = int(np.clip(w / frac, 32, W))
            ar = rng.choice((rng.uniform(1.0, 1.8), rng.uniform(1.8, 4.0), rng.uniform(0.5, 1.0)))
            ch = int(np.clip(cw / ar, 32, H))
            cx0 = int(np.clip(x + w / 2 - rng.uniform(0.15, 0.85) * cw, 0, max(0, W - cw)))
            cy0 = int(np.clip(y + h / 2 - rng.uniform(0.15, 0.85) * ch, 0, max(0, H - ch)))
            img, boxes = _crop(img, boxes, cx0, cy0, cx0 + cw, cy0 + ch)
        elif r < 0.85:
            # random crop (may contain no plate: teaches "nothing here")
            cw, ch = int(W * rng.uniform(0.3, 1.0)), int(H * rng.uniform(0.3, 1.0))
            cx0, cy0 = rng.randint(0, W - cw), rng.randint(0, H - ch)
            img, boxes = _crop(img, boxes, cx0, cy0, cx0 + cw, cy0 + ch)
        if rng.random() < 0.3:
            img = img[:, ::-1].copy()
            Wc = img.shape[1]
            boxes = [[Wc - x - w, y, w, h] for x, y, w, h in boxes]
    lb, s, (dx, dy) = letterbox(img)
    if train:
        lb = _photometric(lb, rng)  # after shrinking: same look, much faster
    boxes = [[x * s + dx, y * s + dy, w * s, h * s] for x, y, w, h in boxes]
    return lb, boxes_to_mask(boxes), boxes
