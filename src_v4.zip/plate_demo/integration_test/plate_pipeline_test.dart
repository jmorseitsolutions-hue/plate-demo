// Runs on an Android emulator: draws a number plate, turns it into the same
// camera-frame layouts real phones send, and checks Google's reader + our
// plate rules find it. Also checks the photo (Safe mode) path.

import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:integration_test/integration_test.dart';
import 'package:plate_demo/scan_core.dart';

const plate = 'MH46DF1352';

Future<ui.Image> drawPlate(int w, int h, {bool rotatedCcw = false}) async {
  final rec = ui.PictureRecorder();
  final c = Canvas(rec);
  c.drawRect(Rect.fromLTWH(0, 0, w.toDouble(), h.toDouble()),
      Paint()..color = const Color(0xFF6E7A85));
  if (rotatedCcw) {
    c.translate(w / 2, h / 2);
    c.rotate(-1.5707963267948966);
    c.translate(-h / 2, -w / 2);
  }
  final cw = rotatedCcw ? h : w, chh = rotatedCcw ? w : h;
  final pw = cw * 0.6, ph = pw * 0.22;
  final left = (cw - pw) / 2, top = (chh - ph) / 2;
  c.drawRect(Rect.fromLTWH(left, top, pw, ph), Paint()..color = Colors.white);
  c.drawRect(
      Rect.fromLTWH(left, top, pw, ph),
      Paint()
        ..color = Colors.black
        ..style = PaintingStyle.stroke
        ..strokeWidth = 4);
  final tp = TextPainter(
    text: TextSpan(
        text: plate,
        style: TextStyle(
            color: Colors.black, fontSize: ph * 0.6, fontWeight: FontWeight.w900, letterSpacing: 2)),
    textDirection: TextDirection.ltr,
  )..layout();
  tp.paint(c, Offset((cw - tp.width) / 2, (chh - tp.height) / 2));
  return rec.endRecording().toImage(w, h);
}

Set<String> found(RecognizedText t) {
  final cleaned = PlateReader.pieces([
    t.text,
    for (final b in t.blocks) b.text,
    for (final b in t.blocks)
      for (final l in b.lines) l.text,
  ]);
  return {
    ...PlateReader.plates(cleaned),
    ...PlateReader.listHits(cleaned, PlateReader.plates(cleaned), {plate}),
  };
}

InputImage nv21Input(Nv21Frame f, int deg) => InputImage.fromBytes(
      bytes: f.bytes,
      metadata: InputImageMetadata(
        size: Size(f.width.toDouble(), f.height.toDouble()),
        rotation: InputImageRotationValue.fromRawValue(deg)!,
        format: InputImageFormat.nv21,
        bytesPerRow: f.width,
      ),
    );

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();
  final recognizer = TextRecognizer(script: TextRecognitionScript.latin);

  testWidgets('Plate is read from every camera frame layout', (tester) async {
    const w = 1280, h = 720;
    final img = await tester.runAsync(() => drawPlate(w, h));
    final rgba = (await tester.runAsync(() => img!.toByteData(format: ui.ImageByteFormat.rawRgba)))!
        .buffer
        .asUint8List();
    final (y, u, v) = TestFrames.rgbaToYuv(rgba, w, h);
    final failures = <String>[];
    for (final e in TestFrames.layouts(w, h, y, u, v).entries) {
      final sw = Stopwatch()..start();
      final f = toNv21(w, h, e.value);
      final text = await tester.runAsync(() => recognizer.processImage(nv21Input(f, 0)));
      sw.stop();
      final hit = found(text!).contains(plate);
      // ignore: avoid_print
      print('RESULT layout="${e.key}" read="${text.text.replaceAll('\n', ' ')}" '
          'match=$hit ms=${sw.elapsedMilliseconds}');
      if (!hit) failures.add(e.key);
    }
    expect(failures, isEmpty, reason: 'Layouts that failed: $failures');
  });

  testWidgets('Rotation value check (info)', (tester) async {
    const w = 1280, h = 720;
    final img = await tester.runAsync(() => drawPlate(w, h, rotatedCcw: true));
    final rgba = (await tester.runAsync(() => img!.toByteData(format: ui.ImageByteFormat.rawRgba)))!
        .buffer
        .asUint8List();
    final (y, u, v) = TestFrames.rgbaToYuv(rgba, w, h);
    final f = toNv21(w, h, TestFrames.layouts(w, h, y, u, v)['1 plane tight']!);
    final ok = <int>[];
    for (final deg in [0, 90, 180, 270]) {
      final text = await tester.runAsync(() => recognizer.processImage(nv21Input(f, deg)));
      if (found(text!).contains(plate)) ok.add(deg);
    }
    // ignore: avoid_print
    print('RESULT rotation: text turned left is read with rotation=$ok');
    expect(ok, isNotEmpty);
  });

  testWidgets('Plate is read from a photo file (Safe mode)', (tester) async {
    final img = await tester.runAsync(() => drawPlate(1280, 720));
    final png = (await tester.runAsync(() => img!.toByteData(format: ui.ImageByteFormat.png)))!;
    final file = File('${Directory.systemTemp.path}/plate_test.png');
    await tester.runAsync(() => file.writeAsBytes(png.buffer.asUint8List()));
    final text = await tester.runAsync(() => recognizer.processImage(InputImage.fromFilePath(file.path)));
    final hit = found(text!).contains(plate);
    // ignore: avoid_print
    print('RESULT photo read="${text.text.replaceAll('\n', ' ')}" match=$hit');
    expect(hit, isTrue);
  });

  testWidgets('1080p: reading band finds the plate and is faster than full frame', (tester) async {
    const w = 1920, h = 1080;
    final img = await tester.runAsync(() => drawPlate(w, h));
    final rgba = (await tester.runAsync(() => img!.toByteData(format: ui.ImageByteFormat.rawRgba)))!
        .buffer
        .asUint8List();
    final (y, u, v) = TestFrames.rgbaToYuv(rgba, w, h);
    final full = toNv21(w, h, TestFrames.layouts(w, h, y, u, v)['1 plane tight']!);
    final band = cropNv21(full, bandFor(w, h, 0, 0.9, 0.45));

    // warm up the reader once so timing is fair
    await tester.runAsync(() => recognizer.processImage(nv21Input(full, 0)));
    var fullMs = 0, bandMs = 0;
    var bandHit = false;
    for (var i = 0; i < 3; i++) {
      final s1 = Stopwatch()..start();
      await tester.runAsync(() => recognizer.processImage(nv21Input(full, 0)));
      fullMs += s1.elapsedMilliseconds;
      final s2 = Stopwatch()..start();
      final t = await tester.runAsync(() => recognizer.processImage(nv21Input(band, 0)));
      bandMs += s2.elapsedMilliseconds;
      bandHit = bandHit || found(t!).contains(plate);
    }
    // ignore: avoid_print
    print('RESULT 1080p full frame ${fullMs ~/ 3} ms, reading band ${bandMs ~/ 3} ms, band match=$bandHit');
    expect(bandHit, isTrue);
  });

  testWidgets('Sharpness pick prefers the sharp frame', (tester) async {
    const w = 1280, h = 720;
    final img = await tester.runAsync(() => drawPlate(w, h));
    final rgba = (await tester.runAsync(() => img!.toByteData(format: ui.ImageByteFormat.rawRgba)))!
        .buffer
        .asUint8List();
    final (y, _, _) = TestFrames.rgbaToYuv(rgba, w, h);
    // smear sideways like a moving bike
    final smeared = Uint8List(w * h);
    for (var r = 0; r < h; r++) {
      for (var c = 0; c < w; c++) {
        var sum = 0, n = 0;
        for (var k = -10; k <= 10; k++) {
          final cc = c + k;
          if (cc >= 0 && cc < w) {
            sum += y[r * w + cc];
            n++;
          }
        }
        smeared[r * w + c] = sum ~/ n;
      }
    }
    final rect = bandFor(w, h, 0, 0.9, 0.45);
    final sSharp = sharpness(y, w, rect, rowStep: 6);
    final sBlur = sharpness(smeared, w, rect, rowStep: 6);
    // ignore: avoid_print
    print('RESULT sharpness sharp=${sSharp.toStringAsFixed(1)} smeared=${sBlur.toStringAsFixed(1)}');
    expect(sSharp > sBlur, isTrue);
  });
}
