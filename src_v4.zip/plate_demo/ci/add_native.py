"""Adds the native shutter code and its libraries to the Android app made by `flutter create`.

Run from the Flutter project folder, after `flutter pub get`:
    python3 ci/add_native.py
It copies MainActivity.java in, removes the default MainActivity.kt, and adds the
CameraX libraries at exactly the version the camera plugin already uses.
"""
import glob, json, os, re, shutil, sys
from urllib.parse import urlparse, unquote

DEFAULT_CAMERAX = '1.4.2'
DEFAULT_GUAVA = '33.3.1-android'


def plugin_dir(project='.'):
    cfg = json.load(open(os.path.join(project, '.dart_tool', 'package_config.json')))
    base = os.path.join(project, '.dart_tool')
    for p in cfg['packages']:
        if p['name'] == 'camera_android_camerax':
            uri = p['rootUri']
            if uri.startswith('file:'):
                return unquote(urlparse(uri).path)
            return os.path.normpath(os.path.join(base, uri))
    return None


def versions(pdir):
    camx, guava = None, None
    texts = []
    for f in glob.glob(os.path.join(pdir or '', 'android', 'build.gradle*')):
        texts.append(open(f).read())
    src = '\n'.join(texts)
    m = re.search(r'androidx\.camera:camera-core:([^"\')\s]+)', src)
    if m:
        v = m.group(1)
        var = re.match(r'\$\{?(\w+)\}?', v)
        if var:
            mv = re.search(r'\b' + var.group(1) + r'\s*=\s*["\']([^"\']+)["\']', src)
            v = mv.group(1) if mv else None
        camx = v
    m = re.search(r'com\.google\.guava:guava:([^"\')\s$]+)', src)
    if m:
        guava = m.group(1)
    return camx or DEFAULT_CAMERAX, guava or DEFAULT_GUAVA


def gradle_block(camx, guava):
    return f'''

// ---- added by ci/add_native.py (PlateAlert fixed-shutter control) ----
dependencies {{
    implementation("androidx.camera:camera-core:{camx}")
    implementation("androidx.camera:camera-camera2:{camx}")
    implementation("androidx.camera:camera-lifecycle:{camx}")
    implementation("com.google.guava:guava:{guava}")
    implementation("androidx.core:core:1.13.1")
}}
android {{
    lint {{
        checkReleaseBuilds = false
        abortOnError = false
    }}
}}
'''


def main(project='.'):
    pdir = plugin_dir(project)
    camx, guava = versions(pdir)
    print(f'camera plugin: {pdir}\nCameraX version: {camx}\nGuava version: {guava}')
    app = os.path.join(project, 'android', 'app')
    for kt in glob.glob(os.path.join(app, 'src', 'main', '**', 'MainActivity.kt'), recursive=True):
        os.remove(kt)
        print('removed', kt)
    dst = os.path.join(app, 'src', 'main', 'java', 'com', 'apexmobilelabs', 'plate_demo')
    os.makedirs(dst, exist_ok=True)
    shutil.copy(os.path.join(project, 'android_extras', 'MainActivity.java'), dst)
    gradle = next((g for g in [os.path.join(app, 'build.gradle.kts'), os.path.join(app, 'build.gradle')] if os.path.exists(g)), None)
    if gradle is None:
        sys.exit('app build.gradle not found')
    with open(gradle, 'a') as fh:
        fh.write(gradle_block(camx, guava))
    print('patched', gradle)


if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv) > 1 else '.')
