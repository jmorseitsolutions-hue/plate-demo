#!/usr/bin/env bash
# Runs on the Android emulator during the GitHub build.
set -u -o pipefail
PKG=com.apexmobilelabs.plate_demo
SUM=${GITHUB_STEP_SUMMARY:-/dev/null}
fail=0
adb wait-for-device
echo "## Phone (emulator) tests" >> "$SUM"

# 1) Plate reading pipeline (Google reader + our rules, all frame layouts)
if flutter test integration_test/plate_pipeline_test.dart -d emulator-5554 2>&1 | tee pipeline.log; then
  echo "- Plate reading test: **PASS**" >> "$SUM"
else
  echo "- Plate reading test: **FAIL**" >> "$SUM"; fail=1
fi
grep -o "RESULT.*" pipeline.log | sed 's/^/    /' >> "$SUM" || true
grep -E "Expected|Actual|Exception|Error:" pipeline.log | head -20 | sed 's/^/    /' >> "$SUM" || true

# 2) The real release app, using the emulator's camera
adb uninstall "$PKG" >/dev/null 2>&1 || true
adb install -r build/app/outputs/flutter-apk/app-release.apk
adb shell pm grant "$PKG" android.permission.CAMERA
adb logcat -c
adb shell monkey -p "$PKG" -c android.intent.category.LAUNCHER 1 >/dev/null
sleep 35
adb logcat -d > release.log
grep -E "PLATEALERT_STATS" release.log | tail -5
last=$(grep -o "PLATEALERT_STATS.*" release.log | tail -1)
echo "- Release app with live camera: \`${last:-no stats line}\`" >> "$SUM"
reads=$(echo "$last" | sed -n 's/.*reads=\([0-9]*\).*/\1/p')
native=$(echo "$last" | sed -n 's/.*native=\([^ ]*\).*/\1/p')
shutter=$(echo "$last" | sed -n 's/.*shutter=\([^ ]*\( ISO[0-9]*\)\{0,1\}\).*/\1/p')
echo "- Fixed-shutter control on emulator: \`${native:-unknown}\` (shutter now: \`${shutter:-?}\`)" >> "$SUM"
grep -o "PLATEALERT_STATS.*" release.log | tail -3 | sed 's/^/    /' >> "$SUM" || true
if [ -n "$reads" ] && [ "$reads" -gt 0 ]; then
  echo "- Live camera scan test: **PASS**" >> "$SUM"
else
  echo "- Live camera scan test: **FAIL**" >> "$SUM"; fail=1
  grep -E "AndroidRuntime|FATAL|Exception|flutter" release.log | head -40 | sed 's/^/    /' >> "$SUM" || true
fi
exit $fail
