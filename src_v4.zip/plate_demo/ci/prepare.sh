#!/usr/bin/env bash
# Turns this folder into a full Android Flutter project. Run from the project folder.
set -euo pipefail
flutter create --platforms=android --project-name plate_demo --org com.apexmobilelabs .
rm -f test/widget_test.dart
cp android_extras/proguard-rules.pro android/app/
sed -i '0,/<application/s//<uses-permission android:name="android.permission.CAMERA"\/>\n    <uses-permission android:name="android.permission.VIBRATE"\/>\n    <application/' android/app/src/main/AndroidManifest.xml
flutter pub get || flutter pub upgrade --major-versions
python3 ci/add_native.py
echo "--- camera packages in use:"
grep -E '"name": "camera' -A1 .dart_tool/package_config.json | grep -oE 'camera[a-z_]*-[0-9][^"/]*' || true
