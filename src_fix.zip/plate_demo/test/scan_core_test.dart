import 'dart:math';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:plate_demo/scan_core.dart';

Set<String> readPlates(String raw) =>
    PlateReader.plates(PlateReader.pieces([raw]));

void main() {
  group('Plate rules', () {
    test('clean plate', () => expect(readPlates('MH46DF1352'), contains('MH46DF1352')));
    test('spaces and dashes', () => expect(readPlates('MH 46 DF-1352'), contains('MH46DF1352')));
    test('IND prefix', () => expect(readPlates('IND MH46DF1352'), contains('MH46DF1352')));
    test('two-line plate', () => expect(readPlates('MH46\nDF1352'), contains('MH46DF1352')));
    test('O/0 and I/1 mix-ups', () {
      expect(readPlates('MH4GDFI352'), contains('MH46DF1352'));
      expect(readPlates('MHO4AB1234'), contains('MH04AB1234'));
    });
    test('one-letter series', () => expect(readPlates('MH04A1234'), contains('MH04A1234')));
    test('BH series', () => expect(readPlates('22BH1234AA'), contains('22BH1234AA')));
    test('junk gives nothing', () {
      expect(readPlates('HELLO WORLD'), isEmpty);
      expect(readPlates('1234567890'), isEmpty);
      expect(readPlates('CALL 9820012345'), isEmpty);
      expect(readPlates('OPEN 24 HOURS'), isEmpty);
    });
    test('list match works even when plate rule fails', () {
      final cleaned = PlateReader.pieces(['XXMH46DF1352YYZZ']);
      final hits = PlateReader.listHits(cleaned, PlateReader.plates(cleaned), {'MH46DF1352'});
      expect(hits, contains('MH46DF1352'));
    });
    test('list match with O/0 confusion', () {
      final cleaned = PlateReader.pieces(['MHO4AB1234']);
      final hits = PlateReader.listHits(cleaned, {}, {'MH04AB1234'});
      expect(hits, contains('MH04AB1234'));
    });
    test('no false match', () {
      final cleaned = PlateReader.pieces(['MH46DF1353']);
      final hits = PlateReader.listHits(cleaned, PlateReader.plates(cleaned), {'MH46DF1352'});
      expect(hits, isEmpty);
    });
  });

  group('Camera frame conversion', () {
    for (final size in [(640, 480), (1280, 720), (1920, 1080)]) {
      test('all layouts give identical NV21 ${size.$1}x${size.$2}', () {
        final w = size.$1, h = size.$2;
        final rnd = Random(7);
        final y = Uint8List.fromList(List.generate(w * h, (_) => rnd.nextInt(256)));
        final u = Uint8List.fromList(List.generate((w ~/ 2) * (h ~/ 2), (_) => rnd.nextInt(256)));
        final v = Uint8List.fromList(List.generate((w ~/ 2) * (h ~/ 2), (_) => rnd.nextInt(256)));
        final ref = TestFrames.reference(w, h, y, u, v);
        TestFrames.layouts(w, h, y, u, v).forEach((name, planes) {
          final f = toNv21(w, h, planes);
          expect(f.width, w, reason: name);
          expect(f.height, h, reason: name);
          expect(f.bytes, equals(ref), reason: name);
        });
      });
    }
  });

  group('Rotation', () {
    test('landscape back camera', () {
      expect(rotationFor(90, 90), 0);
      expect(rotationFor(90, 270), 180);
      expect(rotationFor(90, 0), 90);
    });
  });
}
