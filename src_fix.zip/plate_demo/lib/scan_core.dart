// Pure-Dart logic (no Flutter): plate rules + camera-frame conversion.
// Kept separate so it can be unit-tested on the build server.

import 'dart:typed_data';

/// One colour plane of a camera frame.
class PlaneData {
  final Uint8List bytes;
  final int bytesPerRow;
  final int? bytesPerPixel;
  const PlaneData(this.bytes, this.bytesPerRow, [this.bytesPerPixel]);
}

class Nv21Frame {
  final Uint8List bytes;
  final int width;
  final int height;
  const Nv21Frame(this.bytes, this.width, this.height);
}

/// Builds a tightly packed NV21 buffer (Y rows, then V/U interleaved, no padding)
/// from whatever layout the phone camera gives: 1 plane (NV21, maybe padded)
/// or 3 planes (YUV_420_888 with any row/pixel stride).
Nv21Frame toNv21(int width, int height, List<PlaneData> planes) {
  final w = width - width % 2;
  final h = height - height % 2;
  final out = Uint8List(w * h + (w * h) ~/ 2);
  var idx = 0;

  if (planes.length == 1) {
    final p = planes[0];
    final stride = p.bytesPerRow;
    final b = p.bytes;
    if (stride == w && b.length >= out.length) {
      out.setRange(0, out.length, b);
      return Nv21Frame(out, w, h);
    }
    for (var row = 0; row < h; row++) {
      final start = row * stride;
      final n = _avail(b.length, start, w);
      if (n > 0) out.setRange(idx, idx + n, b, start);
      idx += w;
    }
    final uvStart = stride * height;
    for (var row = 0; row < h ~/ 2; row++) {
      final start = uvStart + row * stride;
      final n = _avail(b.length, start, w);
      if (n > 0) out.setRange(idx, idx + n, b, start);
      for (var k = n < 0 ? 0 : n; k < w; k++) {
        out[idx + k] = 128;
      }
      idx += w;
    }
    return Nv21Frame(out, w, h);
  }

  final y = planes[0], u = planes[1], v = planes[2];
  for (var row = 0; row < h; row++) {
    final start = row * y.bytesPerRow;
    final n = _avail(y.bytes.length, start, w);
    if (n > 0) out.setRange(idx, idx + n, y.bytes, start);
    idx += w;
  }
  final uRow = u.bytesPerRow, uPix = u.bytesPerPixel ?? 1;
  final vRow = v.bytesPerRow, vPix = v.bytesPerPixel ?? 1;
  final ub = u.bytes, vb = v.bytes;
  for (var row = 0; row < h ~/ 2; row++) {
    for (var col = 0; col < w ~/ 2; col++) {
      final vi = row * vRow + col * vPix;
      final ui = row * uRow + col * uPix;
      out[idx++] = vi < vb.length ? vb[vi] : 128;
      out[idx++] = ui < ub.length ? ub[ui] : 128;
    }
  }
  return Nv21Frame(out, w, h);
}

int _avail(int len, int start, int want) {
  final left = len - start;
  if (left <= 0) return 0;
  return left < want ? left : want;
}

/// Back-camera rotation for ML Kit (same formula as Google's ML Kit example).
int rotationFor(int sensorOrientation, int deviceDegrees) =>
    (sensorOrientation - deviceDegrees + 360) % 360;

// ------------------------------------------------------------------
// Plate rules
// ------------------------------------------------------------------
class PlateReader {
  static final _normal = RegExp(r'^[A-Z]{2}[0-9]{1,2}[A-Z]{0,3}[0-9]{4}$');
  static final _bh = RegExp(r'^[0-9]{2}BH[0-9]{4}[A-Z]{1,2}$');
  static const _toLetter = {'0': 'O', '1': 'I', '2': 'Z', '5': 'S', '6': 'G', '8': 'B'};
  static const _toDigit = {
    'O': '0', 'Q': '0', 'D': '0', 'U': '0', 'I': '1', 'L': '1', 'J': '1',
    'Z': '2', 'S': '5', 'G': '6', 'B': '8',
  };

  // Real Indian state / UT codes. A plate must start with one of these.
  static const states = {
    'AN', 'AP', 'AR', 'AS', 'BR', 'CG', 'CH', 'DD', 'DL', 'DN', 'GA', 'GJ',
    'HP', 'HR', 'JH', 'JK', 'KA', 'KL', 'LA', 'LD', 'MH', 'ML', 'MN', 'MP',
    'MZ', 'NL', 'OD', 'OR', 'PB', 'PY', 'RJ', 'SK', 'TG', 'TN', 'TR', 'TS',
    'UK', 'UP', 'WB',
  };

  static String clean(String s) =>
      s.toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]'), '');

  static String? fix(String s) {
    if (_bh.hasMatch(s)) return s;
    if (s.length < 8 || s.length > 10) return null;
    final c = s.split('');
    final n = c.length;
    for (var i = 0; i < 2; i++) {
      c[i] = _toLetter[c[i]] ?? c[i];
    }
    for (var i = 2; i < 4; i++) {
      c[i] = _toDigit[c[i]] ?? c[i];
    }
    for (var i = 4; i < n - 4; i++) {
      c[i] = _toLetter[c[i]] ?? c[i];
    }
    for (var i = n - 4; i < n; i++) {
      c[i] = _toDigit[c[i]] ?? c[i];
    }
    final out = c.join();
    if (!states.contains(out.substring(0, 2))) return null;
    return _normal.hasMatch(out) ? out : null;
  }

  /// Cleans raw text pieces (whole text, blocks, lines).
  static List<String> pieces(Iterable<String> raw) =>
      raw.map(clean).where((s) => s.length >= 4).toList();

  /// Plate-shaped strings found in the text.
  static Set<String> plates(List<String> cleaned) {
    final found = <String>{};
    for (final s in cleaned) {
      if (s.length < 8) continue;
      final maxLen = s.length < 10 ? s.length : 10;
      for (var len = maxLen; len >= 8; len--) {
        final hits = <String>{};
        for (var i = 0; i + len <= s.length; i++) {
          final p = fix(s.substring(i, i + len));
          if (p != null) hits.add(p);
        }
        if (hits.isNotEmpty) {
          found.addAll(hits);
          break;
        }
      }
    }
    return found;
  }

  /// List plates found in the text (plate rule OR loose text match).
  static Set<String> listHits(List<String> cleaned, Set<String> plates, Set<String> list) {
    final hits = <String>{};
    for (final l in list) {
      if (plates.contains(l)) {
        hits.add(l);
        continue;
      }
      final lf = _digitsFixed(l);
      for (final s in cleaned) {
        if (s.contains(l) || _digitsFixed(s).contains(lf)) {
          hits.add(l);
          break;
        }
      }
    }
    return hits;
  }

  static String _digitsFixed(String s) =>
      s.split('').map((ch) => _toDigit[ch] ?? ch).join();
}

// ------------------------------------------------------------------
// Test helpers: build the different frame layouts real phones produce.
// ------------------------------------------------------------------
class TestFrames {
  /// y: w*h, u/v: (w/2)*(h/2). Returns name -> planes.
  static Map<String, List<PlaneData>> layouts(
      int w, int h, Uint8List y, Uint8List u, Uint8List v) {
    final cw = w ~/ 2, ch = h ~/ 2;
    final res = <String, List<PlaneData>>{};

    // A: one plane, tight NV21
    final a = Uint8List(w * h + w * h ~/ 2);
    a.setRange(0, w * h, y);
    var k = w * h;
    for (var i = 0; i < cw * ch; i++) {
      a[k++] = v[i];
      a[k++] = u[i];
    }
    res['1 plane tight'] = [PlaneData(a, w)];

    // B: one plane NV21, padded rows (like many Samsung phones)
    const pad = 64;
    final s = w + pad;
    final b = Uint8List(s * h + s * ch);
    for (var r = 0; r < h; r++) {
      b.setRange(r * s, r * s + w, y, r * w);
    }
    for (var r = 0; r < ch; r++) {
      for (var c = 0; c < cw; c++) {
        b[s * h + r * s + 2 * c] = v[r * cw + c];
        b[s * h + r * s + 2 * c + 1] = u[r * cw + c];
      }
    }
    res['1 plane padded'] = [PlaneData(b, s)];

    // C: three planes, padded, pixelStride 2 (CameraX YUV_420_888 from NV21)
    final yp = Uint8List(s * (h - 1) + w);
    for (var r = 0; r < h; r++) {
      yp.setRange(r * s, r * s + w, y, r * w);
    }
    final vu = Uint8List(s * ch);
    for (var r = 0; r < ch; r++) {
      for (var c = 0; c < cw; c++) {
        vu[r * s + 2 * c] = v[r * cw + c];
        vu[r * s + 2 * c + 1] = u[r * cw + c];
      }
    }
    final vLen = s * (ch - 1) + 2 * (cw - 1) + 1;
    res['3 planes stride 2'] = [
      PlaneData(yp, s, 1),
      PlaneData(Uint8List.sublistView(vu, 1, 1 + vLen), s, 2),
      PlaneData(Uint8List.sublistView(vu, 0, vLen), s, 2),
    ];

    // D: three planes, I420 (pixelStride 1), padded
    final cs = cw + 32;
    final up = Uint8List(cs * ch), vp = Uint8List(cs * ch);
    for (var r = 0; r < ch; r++) {
      up.setRange(r * cs, r * cs + cw, u, r * cw);
      vp.setRange(r * cs, r * cs + cw, v, r * cw);
    }
    res['3 planes stride 1'] = [
      PlaneData(yp, s, 1),
      PlaneData(up, cs, 1),
      PlaneData(vp, cs, 1),
    ];
    return res;
  }

  /// Tight reference NV21 for comparison.
  static Uint8List reference(int w, int h, Uint8List y, Uint8List u, Uint8List v) {
    final a = Uint8List(w * h + w * h ~/ 2);
    a.setRange(0, w * h, y);
    var k = w * h;
    for (var i = 0; i < (w ~/ 2) * (h ~/ 2); i++) {
      a[k++] = v[i];
      a[k++] = u[i];
    }
    return a;
  }

  /// RGBA -> Y, U, V (BT.601), chroma subsampled 2x2.
  static (Uint8List, Uint8List, Uint8List) rgbaToYuv(Uint8List rgba, int w, int h) {
    final y = Uint8List(w * h);
    final u = Uint8List((w ~/ 2) * (h ~/ 2));
    final v = Uint8List((w ~/ 2) * (h ~/ 2));
    for (var r = 0; r < h; r++) {
      for (var c = 0; c < w; c++) {
        final i = (r * w + c) * 4;
        final R = rgba[i], G = rgba[i + 1], B = rgba[i + 2];
        y[r * w + c] = (0.299 * R + 0.587 * G + 0.114 * B).round().clamp(0, 255);
        if (r % 2 == 0 && c % 2 == 0) {
          final j = (r ~/ 2) * (w ~/ 2) + (c ~/ 2);
          u[j] = (-0.169 * R - 0.331 * G + 0.5 * B + 128).round().clamp(0, 255);
          v[j] = (0.5 * R - 0.419 * G - 0.081 * B + 128).round().clamp(0, 255);
        }
      }
    }
    return (y, u, v);
  }
}
