// PlateAlert – scanner v3 (Android)
// Camera upgrades: fixed fast shutter (native), 1080p, zoom, centre reading band,
// sharpest-frame pick, multi-frame voting. Every upgrade can be switched in Settings.
// Fast mode: reads live camera frames. Safe mode: takes quick photos and reads them.

import 'dart:async';
import 'dart:io';

import 'package:audioplayers/audioplayers.dart';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vibration/vibration.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import 'scan_core.dart';

List<CameraDescription> cameras = [];

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]);
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  try {
    cameras = await availableCameras();
  } catch (_) {}
  runApp(const PlateDemoApp());
}

class PlateDemoApp extends StatelessWidget {
  const PlateDemoApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'PlateAlert',
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark(useMaterial3: true),
        home: const ScannerPage(),
      );
}

enum ScanMode { fast, safe }

/// Camera settings the rider can change (saved on the phone).
class CamSettings {
  int shutter = 500; // 0 = phone decides, else 1/shutter seconds
  double zoom = 1.0;
  bool hd = true; // true = 1080p, false = 720p
  int fps = 30;
  bool band = true; // read only the centre band
  bool bestFrame = true; // pick the sharpest frame while the reader is busy
  bool voting = true; // combine several reads to fix single wrong letters

  static const bandW = 0.9;
  static const bandH = 0.45;

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    shutter = p.getInt('cs_shutter') ?? shutter;
    zoom = p.getDouble('cs_zoom') ?? zoom;
    hd = p.getBool('cs_hd') ?? hd;
    fps = p.getInt('cs_fps') ?? fps;
    band = p.getBool('cs_band') ?? band;
    bestFrame = p.getBool('cs_best') ?? bestFrame;
    voting = p.getBool('cs_vote') ?? voting;
  }

  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setInt('cs_shutter', shutter);
    await p.setDouble('cs_zoom', zoom);
    await p.setBool('cs_hd', hd);
    await p.setInt('cs_fps', fps);
    await p.setBool('cs_band', band);
    await p.setBool('cs_best', bestFrame);
    await p.setBool('cs_vote', voting);
  }
}

/// Talks to MainActivity.java, which sets shutter speed and ISO directly
/// on the same camera session the Flutter camera plugin opened.
class ShutterControl {
  static const _ch = MethodChannel('platealert/shutter');
  bool supported = false;
  int minNs = 0, maxNs = 0, minIso = 0, maxIso = 0;
  String status = 'not checked';

  Future<void> probe(String id) async {
    try {
      final m = await _ch.invokeMapMethod<String, dynamic>('info', {'id': id});
      minNs = (m?['minNs'] as num?)?.toInt() ?? 0;
      maxNs = (m?['maxNs'] as num?)?.toInt() ?? 0;
      minIso = (m?['minIso'] as num?)?.toInt() ?? 0;
      maxIso = (m?['maxIso'] as num?)?.toInt() ?? 0;
      supported = m?['manual'] == true && maxNs > 0 && maxIso > 0;
      status = supported ? 'manual OK' : 'phone has no manual shutter';
    } catch (e) {
      supported = false;
      status = 'manual failed: $e';
    }
  }

  Future<bool> manual(String id, ExposureSetting e, int frameNs) async {
    try {
      await _ch.invokeMethod('manual', {'id': id, 'ns': e.exposureNs, 'iso': e.iso, 'frameNs': frameNs});
      return true;
    } catch (err) {
      status = 'manual failed: $err';
      return false;
    }
  }

  Future<void> auto(String id) async {
    try {
      await _ch.invokeMethod('auto', {'id': id});
    } catch (_) {}
  }
}

/// One camera frame waiting to be read.
class _Frame {
  final CameraImage img;
  final double score;
  final int atMs;
  final CropRect rect;
  final int baseRot;
  const _Frame(this.img, this.score, this.atMs, this.rect, this.baseRot);
}

// ------------------------------------------------------------------
// Scanner screen
// ------------------------------------------------------------------
class ScannerPage extends StatefulWidget {
  const ScannerPage({super.key});

  @override
  State<ScannerPage> createState() => _ScannerPageState();
}

class _ScannerPageState extends State<ScannerPage> with WidgetsBindingObserver {
  CameraController? _cam;
  String? _error;
  final _recognizer = TextRecognizer(script: TextRecognitionScript.latin);
  final _player = AudioPlayer();

  ScanMode _mode = ScanMode.fast;
  bool _busy = false;
  bool _paused = false;
  bool _photoLoopRunning = false;
  Timer? _watchdog;

  Set<String> _list = {};
  final CamSettings _set = CamSettings();
  final ShutterControl _shutter = ShutterControl();
  final PlateVoter _voter = PlateVoter();
  String _camId = '';
  double _maxZoom = 1.0;
  _Frame? _pending;
  ExposureSetting? _exp; // current manual exposure (null = phone decides)
  bool _expBusy = false;
  int _lastExpAt = 0;
  int _lastLumaAt = 0;
  double _luma = 0;
  double _sharp = 0;
  int _bestPicks = 0;
  int _voteFixes = 0;
  String _resText = '';
  int _rotExtra = 0;
  int _emptyFrames = 0;
  static const _altRotations = [180, 90, 270];
  Timer? _heartbeat;

  // speed + debug stats
  int _lastMs = 0;
  int _bestMs = 0;
  double _readsPerSec = 0;
  int _rateCount = 0;
  DateTime _rateStart = DateTime.now();
  int _framesIn = 0;
  int _readsOk = 0;
  int _errors = 0;
  String _lastError = '';
  String _rawText = '';

  // plates
  final List<String> _recent = [];
  final Set<String> _allSeen = {};
  final Map<String, List<DateTime>> _sightings = {};
  final Map<String, DateTime> _firstSeen = {};
  final Map<String, DateTime> _muteUntil = {};
  final List<String> _matchLog = [];

  bool _alert = false;
  String _alertPlate = '';
  Timer? _alertTimer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WakelockPlus.enable();
    _loadList();
    _set.load().whenComplete(_startCamera);
    _heartbeat = Timer.periodic(const Duration(seconds: 2), (_) {
      // ignore: avoid_print
      print('PLATEALERT_STATS mode=${_mode.name} frames=$_framesIn reads=$_readsOk '
          'errors=$_errors rot=$_rotExtra ms=$_lastMs res=$_resText zoom=${_set.zoom} '
          'shutter=${_shutterText()} sharp=${_sharp.toStringAsFixed(0)} luma=${_luma.toStringAsFixed(0)} '
          'picks=$_bestPicks votes=$_voteFixes native=${_shutter.status.replaceAll(' ', '_')} '
          'err=${_lastError.replaceAll('\n', ' ')}');
    });
  }

  Future<void> _loadList() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getStringList('plates') ?? ['MH46DF1352'];
    setState(() => _list = saved.map(PlateReader.clean).where((e) => e.isNotEmpty).toSet());
  }

  Future<void> _saveList(Set<String> plates) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('plates', plates.toList());
    setState(() => _list = plates);
  }

  // ---------------- camera ----------------
  Future<void> _startCamera() async {
    if (cameras.isEmpty) {
      try {
        cameras = await availableCameras();
      } catch (_) {}
    }
    if (cameras.isEmpty) {
      setState(() => _error = 'No camera found.');
      return;
    }
    final back = cameras.firstWhere(
      (c) => c.lensDirection == CameraLensDirection.back,
      orElse: () => cameras.first,
    );
    _camId = back.name;
    CameraController make(int? fps) => CameraController(
          back,
          _set.hd ? ResolutionPreset.veryHigh : ResolutionPreset.high,
          enableAudio: false,
          fps: fps,
          imageFormatGroup: ImageFormatGroup.nv21,
        );
    var cam = make(_set.fps);
    try {
      try {
        await cam.initialize();
      } on CameraException {
        // Some phones refuse a fixed frame rate at this size: let the phone choose.
        await cam.dispose();
        cam = make(null);
        await cam.initialize();
      }
      try {
        await cam.setFocusMode(FocusMode.auto);
      } catch (_) {}
      try {
        if (cam.value.focusPointSupported) await cam.setFocusPoint(const Offset(0.5, 0.5));
      } catch (_) {}
      try {
        if (cam.value.exposurePointSupported) await cam.setExposurePoint(const Offset(0.5, 0.5));
      } catch (_) {}
      try {
        await cam.setFlashMode(FlashMode.off);
      } catch (_) {}
      try {
        _maxZoom = await cam.getMaxZoomLevel();
        final minZoom = await cam.getMinZoomLevel();
        await cam.setZoomLevel(_set.zoom.clamp(minZoom, _maxZoom).toDouble());
      } catch (_) {}
      final ps = cam.value.previewSize;
      _resText = ps == null ? '?' : '${ps.width.round()}x${ps.height.round()}';
      _cam = cam;
      if (mounted) setState(() => _error = null);
      await _startMode();
      await _shutter.probe(_camId);
      await _applyShutter();
    } on CameraException catch (e) {
      setState(() => _error = 'Camera problem: ${e.description ?? e.code}\n'
          'Allow camera permission in phone Settings and reopen the app.');
    } catch (e) {
      setState(() => _error = 'Camera problem: $e');
    }
  }

  Future<void> _startMode() async {
    final c = _cam;
    if (c == null) return;
    _watchdog?.cancel();
    if (_mode == ScanMode.fast) {
      try {
        if (!c.value.isStreamingImages) await c.startImageStream(_onFrame);
      } catch (e) {
        _noteError('stream: $e');
        _mode = ScanMode.safe;
        return _startMode();
      }
      // If no successful read in 5 seconds, switch to Safe mode automatically.
      final okAtStart = _readsOk;
      _watchdog = Timer(const Duration(seconds: 5), () {
        if (mounted && _mode == ScanMode.fast && _readsOk == okAtStart && !_paused) {
          _switchMode(ScanMode.safe, auto: true);
        }
      });
    } else {
      try {
        if (c.value.isStreamingImages) await c.stopImageStream();
      } catch (_) {}
      _photoLoop();
    }
  }

  Future<void> _switchMode(ScanMode m, {bool auto = false}) async {
    if (m == _mode) return;
    final c = _cam;
    if (c != null && _mode == ScanMode.fast) {
      try {
        if (c.value.isStreamingImages) await c.stopImageStream();
      } catch (_) {}
    }
    setState(() {
      _mode = m;
      if (auto) _lastError = 'Fast mode not working on this phone → switched to Safe mode. $_lastError';
    });
    await _startMode();
  }

  Future<void> _stopCamera() async {
    _watchdog?.cancel();
    final cam = _cam;
    _cam = null;
    if (cam == null) return;
    try {
      if (cam.value.isStreamingImages) await cam.stopImageStream();
    } catch (_) {}
    // let a running photo/read finish
    for (var i = 0; i < 20 && (_busy || _photoLoopRunning); i++) {
      await Future.delayed(const Duration(milliseconds: 50));
    }
    try {
      await cam.dispose();
    } catch (_) {}
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.inactive || state == AppLifecycleState.paused) {
      _stopCamera();
      if (mounted) setState(() {});
    } else if (state == AppLifecycleState.resumed && _cam == null) {
      _startCamera();
    }
  }

  // ---------------- FAST mode: live frames ----------------
  void _onFrame(CameraImage img) {
    _framesIn++;
    if (_framesIn % 30 == 1) _resText = '${img.width}x${img.height}';
    if (_paused || _mode != ScanMode.fast) return;
    final now = DateTime.now().millisecondsSinceEpoch;
    final base = _baseRotation();
    final w = img.width - img.width % 2;
    final h = img.height - img.height % 2;
    final rect = _set.band
        ? bandFor(w, h, (base + _rotExtra) % 360, CamSettings.bandW, CamSettings.bandH)
        : CropRect(0, 0, w, h);
    final y = img.planes[0];

    // Brightness for the fixed-shutter loop (cheap, a few times a second).
    if (now - _lastLumaAt >= 150) {
      _lastLumaAt = now;
      _luma = meanLuma(y.bytes, y.bytesPerRow, rect);
      _exposureStep(now);
    }

    if (!_set.bestFrame) {
      if (_busy) return;
      _busy = true;
      _processFrame(_Frame(img, 0, now, rect, base)).whenComplete(() => _busy = false);
      return;
    }

    final score = sharpness(y.bytes, y.bytesPerRow, rect, rowStep: 6);
    _sharp = score;
    final p = _pending;
    if (_busy) {
      // Reader is busy: remember the sharpest recent frame for next time.
      if (p == null || now - p.atMs > 250 || score > p.score) {
        _pending = _Frame(img, score, now, rect, base);
      }
      return;
    }
    var use = _Frame(img, score, now, rect, base);
    if (p != null && now - p.atMs <= 250 && p.score > score) {
      use = p;
      _bestPicks++;
    }
    _pending = null;
    _busy = true;
    _processFrame(use).whenComplete(() => _busy = false);
  }

  Future<void> _processFrame(_Frame f) async {
    final t = DateTime.fromMillisecondsSinceEpoch(f.atMs);
    final sw = Stopwatch()..start();
    try {
      var frame = _frameOf(f.img);
      final r = f.rect;
      if (r.left + r.width <= frame.width && r.top + r.height <= frame.height) {
        frame = cropNv21(frame, r);
      }
      final base = f.baseRot;
      var text = await _recognizer.processImage(_makeInput(frame, base + _rotExtra));
      if (text.blocks.isEmpty) {
        // Nothing found: every 3rd empty frame, try another angle in case
        // the phone reports its orientation differently.
        _emptyFrames++;
        if (_emptyFrames % 3 == 0) {
          final alt = _altRotations[(_emptyFrames ~/ 3) % _altRotations.length];
          final tryExtra = (_rotExtra + alt) % 360;
          final t2 = await _recognizer.processImage(_makeInput(frame, base + tryExtra));
          if (t2.blocks.isNotEmpty) {
            _rotExtra = tryExtra;
            text = t2;
          }
        }
      } else {
        _emptyFrames = 0;
      }
      _afterRead(text, sw, t);
    } catch (e) {
      _noteError('read: $e');
    }
  }

  // ---------------- fixed fast shutter ----------------
  int get _targetNs => _set.shutter <= 0 ? 0 : 1000000000 ~/ _set.shutter;

  String _shutterText() {
    final e = _exp;
    if (e == null) return _set.shutter <= 0 ? 'auto' : 'auto(${_shutter.status})';
    return '1/${(1e9 / e.exposureNs).round()} ISO${e.iso}';
  }

  Future<void> _applyShutter() async {
    if (_camId.isEmpty) return;
    if (_set.shutter <= 0 || !_shutter.supported) {
      if (_exp != null) await _shutter.auto(_camId);
      _exp = null;
      if (mounted) setState(() {});
      return;
    }
    // Start at the chosen shutter with a middle ISO, then the loop fixes brightness.
    final iso = 400.clamp(_shutter.minIso, _shutter.maxIso).toInt();
    final ns = _targetNs.clamp(_shutter.minNs, _shutter.maxNs).toInt();
    final first = ExposureSetting(ns, iso);
    final ok = await _shutter.manual(_camId, first, _frameNs(ns));
    _exp = ok ? first : null;
    _lastExpAt = DateTime.now().millisecondsSinceEpoch;
    if (!ok) _shutter.supported = false;
    if (mounted) setState(() {});
  }

  int _frameNs(int exposureNs) {
    final perFrame = 1000000000 ~/ (_set.fps <= 0 ? 30 : _set.fps);
    return exposureNs > perFrame ? exposureNs : perFrame;
  }

  void _exposureStep(int now) {
    final cur = _exp;
    if (cur == null || _expBusy || now - _lastExpAt < 300 || _camId.isEmpty) return;
    final target = _targetNs;
    final slowest = target * 4 < 8000000 ? target * 4 : (target > 8000000 ? target : 8000000);
    final next = nextExposure(
      meanY: _luma,
      current: cur,
      targetNs: target,
      slowestNs: slowest,
      minNs: _shutter.minNs,
      maxNs: _shutter.maxNs,
      minIso: _shutter.minIso,
      maxIso: _shutter.maxIso,
    );
    if (next == null) return;
    _expBusy = true;
    _lastExpAt = now;
    _shutter.manual(_camId, next, _frameNs(next.exposureNs)).then((ok) {
      if (ok) {
        _exp = next;
      } else {
        _exp = null;
        _shutter.supported = false;
      }
    }).whenComplete(() => _expBusy = false);
  }

  int _baseRotation() {
    final c = _cam;
    if (c == null) return 0;
    const orient = {
      DeviceOrientation.portraitUp: 0,
      DeviceOrientation.landscapeLeft: 90,
      DeviceOrientation.portraitDown: 180,
      DeviceOrientation.landscapeRight: 270,
    };
    final dev = orient[c.value.deviceOrientation] ?? 90;
    return rotationFor(c.description.sensorOrientation, dev);
  }

  InputImage _makeInput(Nv21Frame f, int degrees) => InputImage.fromBytes(
        bytes: f.bytes,
        metadata: InputImageMetadata(
          size: Size(f.width.toDouble(), f.height.toDouble()),
          rotation: InputImageRotationValue.fromRawValue(degrees % 360) ??
              InputImageRotation.rotation0deg,
          format: InputImageFormat.nv21,
          bytesPerRow: f.width,
        ),
      );

  Nv21Frame _frameOf(CameraImage img) => toNv21(
        img.width,
        img.height,
        img.planes.map((p) => PlaneData(p.bytes, p.bytesPerRow, p.bytesPerPixel)).toList(),
      );

  // ---------------- SAFE mode: quick photos ----------------
  Future<void> _photoLoop() async {
    if (_photoLoopRunning) return;
    _photoLoopRunning = true;
    try {
      while (mounted && _mode == ScanMode.safe) {
        final c = _cam;
        if (c == null) break;
        if (_paused || !c.value.isInitialized || c.value.isTakingPicture) {
          await Future.delayed(const Duration(milliseconds: 200));
          continue;
        }
        final t = DateTime.now();
        final sw = Stopwatch()..start();
        try {
          final file = await c.takePicture();
          _framesIn++;
          final text = await _recognizer.processImage(InputImage.fromFilePath(file.path));
          _afterRead(text, sw, t);
          File(file.path).delete().catchError((_) => File(file.path));
        } catch (e) {
          _noteError('photo: $e');
          await Future.delayed(const Duration(milliseconds: 400));
        }
      }
    } finally {
      _photoLoopRunning = false;
    }
  }

  // ---------------- shared ----------------
  void _noteError(String e) {
    _errors++;
    _lastError = e.length > 120 ? e.substring(0, 120) : e;
    if (mounted) setState(() {});
  }

  void _afterRead(RecognizedText text, Stopwatch sw, DateTime t) {
    final cleaned = PlateReader.pieces([
      text.text,
      for (final b in text.blocks) b.text,
      for (final b in text.blocks)
        for (final l in b.lines) l.text,
    ]);
    final plates = PlateReader.plates(cleaned);
    final hits = PlateReader.listHits(cleaned, plates, _list);
    sw.stop();

    _readsOk++;
    _rateCount++;
    final now = DateTime.now();
    final elapsed = now.difference(_rateStart).inMilliseconds;
    if (elapsed >= 1000) {
      _readsPerSec = _rateCount * 1000 / elapsed;
      _rateCount = 0;
      _rateStart = now;
    }
    for (final p in plates) {
      _allSeen.add(p);
      _recent.remove(p);
      _recent.insert(0, p);
      if (_recent.length > 6) _recent.removeLast();
    }
    for (final h in hits) {
      _confirm(h, t);
    }
    if (_set.voting && _mode == ScanMode.fast) {
      final agreed = _voter.add(plates, t.millisecondsSinceEpoch);
      for (final a in agreed) {
        if (!_list.contains(a) || hits.contains(a)) continue;
        // Several reads, each slightly wrong, agree on a listed plate.
        final mute = _muteUntil[a];
        if (mute != null && t.isBefore(mute)) continue;
        _voteFixes++;
        _muteUntil[a] = DateTime.now().add(const Duration(seconds: 30));
        _fireAlert(a, _lastMs);
      }
    }
    if (!mounted) return;
    setState(() {
      _lastMs = sw.elapsedMilliseconds;
      if (_bestMs == 0 || _lastMs < _bestMs) _bestMs = _lastMs;
      final raw = text.text.replaceAll('\n', ' ').trim();
      if (raw.isNotEmpty) _rawText = raw.length > 60 ? raw.substring(0, 60) : raw;
    });
  }

  void _confirm(String p, DateTime t) {
    final mute = _muteUntil[p];
    if (mute != null && t.isBefore(mute)) return;
    final need = _mode == ScanMode.fast ? 2 : 1; // safe mode is slower, 1 clear read is enough
    final s = _sightings.putIfAbsent(p, () => []);
    s.removeWhere((x) => t.difference(x).inMilliseconds > 3000);
    if (s.isEmpty) _firstSeen[p] = t;
    s.add(t);
    if (s.length >= need) {
      final delayMs = DateTime.now().difference(_firstSeen[p]!).inMilliseconds + _lastMs;
      _muteUntil[p] = DateTime.now().add(const Duration(seconds: 30));
      s.clear();
      _fireAlert(p, delayMs);
    }
  }

  Future<void> _fireAlert(String p, int delayMs) async {
    final time = TimeOfDay.now().format(context);
    setState(() {
      _alert = true;
      _alertPlate = p;
      _matchLog.insert(0, '$p   $time   caught in ${(delayMs / 1000).toStringAsFixed(2)}s');
    });
    try {
      await _player.stop();
      await _player.play(AssetSource('beep.wav'), volume: 1.0);
    } catch (_) {}
    try {
      if (await Vibration.hasVibrator() == true) {
        Vibration.vibrate(duration: 1200);
      }
    } catch (_) {
      HapticFeedback.heavyImpact();
    }
    _alertTimer?.cancel();
    _alertTimer = Timer(const Duration(seconds: 3), () {
      if (mounted) setState(() => _alert = false);
    });
  }

  void _reset() {
    setState(() {
      _recent.clear();
      _allSeen.clear();
      _sightings.clear();
      _firstSeen.clear();
      _muteUntil.clear();
      _matchLog.clear();
      _bestMs = 0;
      _bestPicks = 0;
      _voteFixes = 0;
      _voter.clear();
      _errors = 0;
      _lastError = '';
      _rawText = '';
    });
  }

  Future<void> _editList() async {
    final result = await Navigator.of(context).push<Set<String>>(
      MaterialPageRoute(builder: (_) => ListEditorPage(initial: _list)),
    );
    if (result != null) {
      await _saveList(result);
      _muteUntil.clear();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _alertTimer?.cancel();
    _watchdog?.cancel();
    _heartbeat?.cancel();
    _stopCamera();
    _recognizer.close();
    _player.dispose();
    WakelockPlus.disable();
    super.dispose();
  }

  // ---------------- UI ----------------
  @override
  Widget build(BuildContext context) {
    final cam = _cam;
    final modeName = _mode == ScanMode.fast ? 'FAST mode (live video)' : 'SAFE mode (quick photos)';
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          Positioned.fill(
            child: (cam != null && cam.value.isInitialized)
                ? Center(
                    child: CameraPreview(
                      cam,
                      child: _set.band
                          ? IgnorePointer(
                              child: Center(
                                child: FractionallySizedBox(
                                  widthFactor: CamSettings.bandW,
                                  heightFactor: CamSettings.bandH,
                                  child: Container(
                                    decoration: BoxDecoration(
                                      border: Border.all(
                                          color: Colors.greenAccent.withOpacity(0.8), width: 2),
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                  ),
                                ),
                              ),
                            )
                          : null,
                    ),
                  )
                : Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Text(_error ?? 'Starting camera…',
                          textAlign: TextAlign.center, style: const TextStyle(fontSize: 18)),
                    ),
                  ),
          ),
          Positioned(
            left: 12,
            top: 12,
            child: _panel(width: 230, children: [
              const Text('SPEED', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.amber)),
              const SizedBox(height: 6),
              _big('$_lastMs ms', 'one read (latest)'),
              _big('$_bestMs ms', 'fastest read'),
              _big(_readsPerSec.toStringAsFixed(1), 'checks per second'),
              const Divider(),
              Text('Plates on list: ${_list.length}'),
              Text('Plates read so far: ${_allSeen.length}'),
              Text(_paused ? 'PAUSED' : modeName,
                  style: TextStyle(color: _paused ? Colors.orange : Colors.greenAccent, fontSize: 12)),
            ]),
          ),
          Positioned(
            right: 12,
            top: 12,
            child: _panel(width: 280, children: [
              const Text('PLATES READ', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.amber)),
              const SizedBox(height: 4),
              if (_recent.isEmpty) const Text('— point at a plate —', style: TextStyle(color: Colors.white54)),
              ..._recent.map((p) => Text(p,
                  style: TextStyle(
                    fontSize: 18,
                    fontFamily: 'monospace',
                    color: _list.contains(p) ? Colors.redAccent : Colors.white,
                  ))),
              const Divider(),
              const Text('MATCHES', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.redAccent)),
              if (_matchLog.isEmpty) const Text('none yet', style: TextStyle(color: Colors.white54)),
              ..._matchLog.take(4).map((m) => Text(m, style: const TextStyle(fontSize: 12))),
            ]),
          ),
          // debug strip
          Positioned(
            left: 12,
            right: 12,
            bottom: 64,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              color: Colors.black.withOpacity(0.6),
              child: Text(
                'Camera: $_resText  zoom ${_set.zoom}x  shutter ${_shutterText()}  '
                'sharpness ${_sharp.toStringAsFixed(0)}  brightness ${_luma.toStringAsFixed(0)}  '
                'sharp picks $_bestPicks  vote fixes $_voteFixes\n'
                'Camera frames: $_framesIn   Reads done: $_readsOk   Errors: $_errors'
                '${_lastError.isNotEmpty ? '  ($_lastError)' : ''}\n'
                'Text seen: ${_rawText.isEmpty ? '—' : _rawText}',
                maxLines: 4,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 11, color: Colors.white70),
              ),
            ),
          ),
          Positioned(
            bottom: 12,
            left: 0,
            right: 0,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _btn(_paused ? Icons.play_arrow : Icons.pause, _paused ? 'Resume' : 'Pause',
                    () => setState(() => _paused = !_paused)),
                const SizedBox(width: 10),
                _btn(Icons.swap_horiz, _mode == ScanMode.fast ? 'Use Safe' : 'Use Fast',
                    () => _switchMode(_mode == ScanMode.fast ? ScanMode.safe : ScanMode.fast)),
                const SizedBox(width: 10),
                _btn(Icons.list_alt, 'Test list', _editList),
                const SizedBox(width: 10),
                _btn(Icons.tune, 'Camera', _openSettings),
                const SizedBox(width: 10),
                _btn(Icons.refresh, 'Reset', _reset),
              ],
            ),
          ),
          if (_alert)
            Positioned.fill(
              child: GestureDetector(
                onTap: () => setState(() => _alert = false),
                child: Container(
                  color: Colors.red.withOpacity(0.85),
                  alignment: Alignment.center,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text('DEFAULTER MATCH',
                          style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900)),
                      const SizedBox(height: 12),
                      Text(_alertPlate,
                          style: const TextStyle(
                              fontSize: 56, fontWeight: FontWeight.w900, fontFamily: 'monospace')),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ---------------- camera settings sheet ----------------
  Future<void> _restartCamera() async {
    _exp = null;
    _pending = null;
    await _stopCamera();
    if (mounted) setState(() {});
    await _startCamera();
  }

  Future<void> _openSettings() async {
    final shutterNote = _shutter.supported ? '' : '  (${_shutter.status})';
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) {
          Future<void> change(Future<void> Function() action) async {
            await action();
            await _set.save();
            if (ctx.mounted) setSheet(() {});
            if (mounted) setState(() {});
          }

          Widget row(String title, String help, Widget control) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 6),
                child: Row(
                  children: [
                    SizedBox(
                      width: 230,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
                          Text(help, style: const TextStyle(fontSize: 11, color: Colors.white60)),
                        ],
                      ),
                    ),
                    Expanded(child: control),
                  ],
                ),
              );

          SegmentedButton<T> seg<T>(T value, Map<T, String> options, void Function(T) onPick) =>
              SegmentedButton<T>(
                showSelectedIcon: false,
                segments: [
                  for (final e in options.entries) ButtonSegment<T>(value: e.key, label: Text(e.value)),
                ],
                selected: {value},
                onSelectionChanged: (v) => onPick(v.first),
              );

          return SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  row(
                    'Shutter speed$shutterNote',
                    'Faster = less blur on a moving bike',
                    seg<int>(_set.shutter, {0: 'Auto', 250: '1/250', 500: '1/500', 1000: '1/1000'},
                        (v) => change(() async {
                              _set.shutter = v;
                              await _applyShutter();
                            })),
                  ),
                  row(
                    'Zoom (max ${_maxZoom.toStringAsFixed(1)}x)',
                    'More zoom = reads farther, sees less road',
                    seg<double>(_set.zoom, {1.0: '1x', 1.5: '1.5x', 2.0: '2x', 3.0: '3x'},
                        (v) => change(() async {
                              _set.zoom = v;
                              try {
                                await _cam?.setZoomLevel(v.clamp(1.0, _maxZoom).toDouble());
                              } catch (_) {}
                            })),
                  ),
                  row(
                    'Picture size',
                    '1080p = 1.5x more detail, a bit slower',
                    seg<bool>(_set.hd, {false: '720p', true: '1080p'}, (v) => change(() async {
                          _set.hd = v;
                          await _restartCamera();
                        })),
                  ),
                  row(
                    'Frames per second',
                    '60 = more chances per car (needs a good phone)',
                    seg<int>(_set.fps, {30: '30', 60: '60'}, (v) => change(() async {
                          _set.fps = v;
                          await _restartCamera();
                        })),
                  ),
                  row(
                    'Read only the green band',
                    'Faster reads, fewer junk words',
                    seg<bool>(_set.band, {true: 'On', false: 'Off'}, (v) => change(() async {
                          _set.band = v;
                        })),
                  ),
                  row(
                    'Pick sharpest frame',
                    'Skips blurry frames while reading',
                    seg<bool>(_set.bestFrame, {true: 'On', false: 'Off'}, (v) => change(() async {
                          _set.bestFrame = v;
                          _pending = null;
                        })),
                  ),
                  row(
                    'Combine reads (voting)',
                    'Fixes single wrong letters using 3+ reads',
                    seg<bool>(_set.voting, {true: 'On', false: 'Off'}, (v) => change(() async {
                          _set.voting = v;
                          _voter.clear();
                        })),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _panel({required double width, required List<Widget> children}) => Container(
        width: width,
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.6),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: children),
      );

  Widget _big(String value, String label) => Padding(
        padding: const EdgeInsets.only(bottom: 4),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(value, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
            const SizedBox(width: 6),
            Flexible(child: Text(label, style: const TextStyle(fontSize: 12, color: Colors.white70))),
          ],
        ),
      );

  Widget _btn(IconData icon, String label, VoidCallback onTap) => FilledButton.tonalIcon(
        onPressed: onTap,
        icon: Icon(icon),
        label: Text(label),
      );
}

// ------------------------------------------------------------------
// Test list editor
// ------------------------------------------------------------------
class ListEditorPage extends StatefulWidget {
  final Set<String> initial;
  const ListEditorPage({super.key, required this.initial});

  @override
  State<ListEditorPage> createState() => _ListEditorPageState();
}

class _ListEditorPageState extends State<ListEditorPage> {
  late final TextEditingController _ctrl =
      TextEditingController(text: widget.initial.join('\n'));

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _save() {
    final plates = _ctrl.text
        .split(RegExp(r'[\n,;]'))
        .map(PlateReader.clean)
        .where((e) => e.length >= 6)
        .toSet();
    Navigator.of(context).pop(plates);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Test list (one plate per line)'),
        actions: [
          TextButton.icon(onPressed: _save, icon: const Icon(Icons.check), label: const Text('Save')),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: TextField(
          controller: _ctrl,
          maxLines: null,
          expands: true,
          textCapitalization: TextCapitalization.characters,
          style: const TextStyle(fontFamily: 'monospace', fontSize: 18),
          decoration: const InputDecoration(
            border: OutlineInputBorder(),
            hintText: 'MH46DF1352\nMH04AB1234',
          ),
        ),
      ),
    );
  }
}
