// PlateAlert – scanner v5 (Android)
// v5: Rider screen (full-screen camera, upright or sideways), adjustable reading area,
// match alert with photo + voice + WhatsApp share with GPS, match log, Excel/CSV list import.
//
// (v4 notes)
// v4: Fast traffic mode (1/2000 shutter, 60 fps, 2x), up to 4K and 5x zoom,
// two readers working at once on fast phones.
// Camera upgrades: fixed fast shutter (native), 1080p, zoom, centre reading band,
// sharpest-frame pick, multi-frame voting. Every upgrade can be switched in Settings.
// Fast mode: reads live camera frames. Safe mode: takes quick photos and reads them.

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:audioplayers/audioplayers.dart';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vibration/vibration.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import 'scan_core.dart';

List<CameraDescription> cameras = [];

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]);
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  try {
    cameras = await availableCameras();
  } catch (_) {}
  runApp(const PlateDemoApp());
}

class PlateDemoApp extends StatelessWidget {
  const PlateDemoApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'PlateAlert',
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark(useMaterial3: true),
        home: const ScannerPage(),
      );
}

enum ScanMode { fast, safe }

/// Camera settings the rider can change (saved on the phone).
class CamSettings {
  int shutter = 500; // 0 = phone decides, else 1/shutter seconds
  double zoom = 1.0;
  int res = 1080; // picture height: 720, 1080 or 2160 (4K)
  int fps = 30;
  int readers = Platform.numberOfProcessors >= 8 ? 2 : 1; // reads at the same time
  bool fastMode = false; // tuned for cars moving at speed
  int rotation = 0; // 0 = auto, 1 = upright (portrait), 2 = sideways (landscape)
  int area = 0; // reading area: 0 = normal, 1 = tall, 2 = full screen
  bool details = false; // show all the numbers on screen
  bool voice = true; // speak the plate on a match
  bool band = true; // read only the centre band
  bool bestFrame = true; // pick the sharpest frame while the reader is busy
  bool voting = true; // combine several reads to fix single wrong letters

  /// One tap: settings for cars moving at speed.
  void applyFast() {
    fastMode = true;
    shutter = 2000;
    fps = 60;
    zoom = 2.0;
    res = 1080;
    band = true;
    bestFrame = true;
  }

  /// One tap back: settings for parked / slow cars.
  void applyParked() {
    fastMode = false;
    shutter = 500;
    fps = 30;
    zoom = 1.0;
    res = 1080;
  }

  /// How long a waiting frame stays useful (fast cars leave the picture quickly).
  int get pendingMs => fastMode ? 120 : 250;

  ResolutionPreset get preset => res >= 2160
      ? ResolutionPreset.ultraHigh
      : (res >= 1080 ? ResolutionPreset.veryHigh : ResolutionPreset.high);

  /// Reading band as a fraction of the SCREEN (width, height).
  (double, double) bandScreen(bool portrait) {
    switch (area) {
      case 2:
        return (1.0, 1.0);
      case 1:
        return portrait ? (1.0, 0.55) : (0.95, 0.7);
      default:
        return portrait ? (0.95, 0.3) : (0.9, 0.45);
    }
  }

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    shutter = p.getInt('cs_shutter') ?? shutter;
    zoom = p.getDouble('cs_zoom') ?? zoom;
    res = p.getInt('cs_res') ?? res;
    readers = p.getInt('cs_readers') ?? readers;
    fastMode = p.getBool('cs_fast') ?? fastMode;
    rotation = p.getInt('cs_rot') ?? rotation;
    area = p.getInt('cs_area') ?? area;
    details = p.getBool('cs_details') ?? details;
    voice = p.getBool('cs_voice') ?? voice;
    fps = p.getInt('cs_fps') ?? fps;
    band = p.getBool('cs_band') ?? band;
    bestFrame = p.getBool('cs_best') ?? bestFrame;
    voting = p.getBool('cs_vote') ?? voting;
  }

  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setInt('cs_shutter', shutter);
    await p.setDouble('cs_zoom', zoom);
    await p.setInt('cs_res', res);
    await p.setInt('cs_readers', readers);
    await p.setBool('cs_fast', fastMode);
    await p.setInt('cs_rot', rotation);
    await p.setInt('cs_area', area);
    await p.setBool('cs_details', details);
    await p.setBool('cs_voice', voice);
    await p.setInt('cs_fps', fps);
    await p.setBool('cs_band', band);
    await p.setBool('cs_best', bestFrame);
    await p.setBool('cs_vote', voting);
  }
}

/// Talks to MainActivity.java, which sets shutter speed and ISO directly
/// on the same camera session the Flutter camera plugin opened.
class ShutterControl {
  static const _ch = MethodChannel('platealert/shutter');
  bool supported = false;
  int minNs = 0, maxNs = 0, minIso = 0, maxIso = 0;
  String status = 'not checked';

  Future<void> probe(String id) async {
    try {
      final m = await _ch.invokeMapMethod<String, dynamic>('info', {'id': id});
      minNs = (m?['minNs'] as num?)?.toInt() ?? 0;
      maxNs = (m?['maxNs'] as num?)?.toInt() ?? 0;
      minIso = (m?['minIso'] as num?)?.toInt() ?? 0;
      maxIso = (m?['maxIso'] as num?)?.toInt() ?? 0;
      supported = m?['manual'] == true && maxNs > 0 && maxIso > 0;
      status = supported ? 'manual OK' : 'phone has no manual shutter';
    } catch (e) {
      supported = false;
      status = 'manual failed: $e';
    }
  }

  Future<bool> manual(String id, ExposureSetting e, int frameNs) async {
    try {
      await _ch.invokeMethod('manual', {'id': id, 'ns': e.exposureNs, 'iso': e.iso, 'frameNs': frameNs});
      return true;
    } catch (err) {
      status = 'manual failed: $err';
      return false;
    }
  }

  Future<void> auto(String id) async {
    try {
      await _ch.invokeMethod('auto', {'id': id});
    } catch (_) {}
  }
}

/// Voice, file picking and the app's storage folder (MainActivity.java).
class Native {
  static const _ch = MethodChannel('platealert/native');

  static Future<void> speak(String text) async {
    try {
      await _ch.invokeMethod('speak', {'text': text});
    } catch (_) {}
  }

  static Future<String> filesDir() async =>
      (await _ch.invokeMethod<String>('filesDir')) ?? Directory.systemTemp.path;

  /// Opens the phone's file chooser. Returns every cell's text, or null if cancelled.
  static Future<List<String>?> pickList() => _ch.invokeListMethod<String>('pickList');
}

/// One saved match (evidence).
class MatchRecord {
  final String plate;
  final DateTime time;
  double? lat;
  double? lng;
  String? photo;
  MatchRecord(this.plate, this.time, {this.lat, this.lng, this.photo});

  Map<String, dynamic> toJson() => {
        'plate': plate,
        'time': time.millisecondsSinceEpoch,
        'lat': lat,
        'lng': lng,
        'photo': photo,
      };

  static MatchRecord fromJson(Map<String, dynamic> j) => MatchRecord(
        j['plate'] as String,
        DateTime.fromMillisecondsSinceEpoch(j['time'] as int),
        lat: (j['lat'] as num?)?.toDouble(),
        lng: (j['lng'] as num?)?.toDouble(),
        photo: j['photo'] as String?,
      );

  String get mapLink => lat == null ? '' : 'https://maps.google.com/?q=$lat,$lng';

  String get timeText {
    const m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    String two(int v) => v.toString().padLeft(2, '0');
    return '${time.day} ${m[time.month - 1]} ${time.year}, ${two(time.hour)}:${two(time.minute)}';
  }

  String get shareText => 'PlateAlert match: ${prettyPlate(plate)}\nTime: $timeText'
      '${lat == null ? '' : '\nLocation: $mapLink'}';
}

/// The camera frame a plate was read from (for the match photo).
class _Snap {
  final Nv21Frame frame;
  final int rot; // clockwise degrees to make it upright
  const _Snap(this.frame, this.rot);
}

/// What the red match screen shows.
class _AlertInfo {
  final MatchRecord rec;
  ui.Image? photo;
  int quarterTurns = 0;
  _AlertInfo(this.rec);
}

/// One camera frame waiting to be read.
class _Frame {
  final CameraImage img;
  final double score;
  final int atMs;
  final CropRect rect;
  final int baseRot;
  const _Frame(this.img, this.score, this.atMs, this.rect, this.baseRot);
}

// ------------------------------------------------------------------
// Scanner screen
// ------------------------------------------------------------------
class ScannerPage extends StatefulWidget {
  const ScannerPage({super.key});

  @override
  State<ScannerPage> createState() => _ScannerPageState();
}

class _ScannerPageState extends State<ScannerPage> with WidgetsBindingObserver {
  CameraController? _cam;
  String? _error;
  final _recognizers = [
    TextRecognizer(script: TextRecognitionScript.latin),
    TextRecognizer(script: TextRecognitionScript.latin),
  ];
  int _nextReader = 0;
  TextRecognizer get _recognizer => _recognizers[0];
  TextRecognizer _takeReader() {
    final r = _recognizers[_nextReader % _recognizers.length];
    _nextReader++;
    return r;
  }
  final _player = AudioPlayer();

  ScanMode _mode = ScanMode.fast;
  int _inFlight = 0; // reads running right now
  bool get _busy => _inFlight >= (_set.readers < 1 ? 1 : _set.readers);
  bool _paused = false;
  bool _photoLoopRunning = false;
  Timer? _watchdog;

  Set<String> _list = {};
  final CamSettings _set = CamSettings();
  final ShutterControl _shutter = ShutterControl();
  final PlateVoter _voter = PlateVoter();
  String _camId = '';
  double _maxZoom = 1.0;
  _Frame? _pending;
  ExposureSetting? _exp; // current manual exposure (null = phone decides)
  bool _expBusy = false;
  int _lastExpAt = 0;
  int _lastLumaAt = 0;
  double _luma = 0;
  double _sharp = 0;
  int _bestPicks = 0;
  int _voteFixes = 0;
  String _resText = '';
  double _screenAspect = 16 / 9; // width / height of the camera area on screen
  bool _portrait = false;
  final List<MatchRecord> _log = [];
  _AlertInfo? _alertInfo;
  int _rotExtra = 0;
  int _emptyFrames = 0;
  static const _altRotations = [180, 90, 270];
  Timer? _heartbeat;

  // speed + debug stats
  int _lastMs = 0;
  int _bestMs = 0;
  double _readsPerSec = 0;
  int _rateCount = 0;
  DateTime _rateStart = DateTime.now();
  int _framesIn = 0;
  int _readsOk = 0;
  int _errors = 0;
  String _lastError = '';
  String _rawText = '';

  // plates
  final List<String> _recent = [];
  final Set<String> _allSeen = {};
  final Map<String, List<DateTime>> _sightings = {};
  final Map<String, DateTime> _firstSeen = {};
  final Map<String, DateTime> _muteUntil = {};
  final List<String> _matchLog = [];

  bool _alert = false;
  String _alertPlate = '';
  Timer? _alertTimer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WakelockPlus.enable();
    _loadList();
    _loadLog();
    _set.load().whenComplete(() async {
      await _applyRotation();
      await _position(ask: true); // ask for location once, before the camera starts
      await _startCamera();
    });
    _heartbeat = Timer.periodic(const Duration(seconds: 2), (_) {
      // ignore: avoid_print
      print('PLATEALERT_STATS mode=${_mode.name} frames=$_framesIn reads=$_readsOk '
          'errors=$_errors rot=$_rotExtra ms=$_lastMs res=$_resText zoom=${_set.zoom} '
          'fast=${_set.fastMode} readers=${_set.readers} inflight=$_inFlight '
          'shutter=${_shutterText()} sharp=${_sharp.toStringAsFixed(0)} luma=${_luma.toStringAsFixed(0)} '
          'picks=$_bestPicks votes=$_voteFixes native=${_shutter.status.replaceAll(' ', '_')} '
          'err=${_lastError.replaceAll('\n', ' ')}');
    });
  }

  Future<void> _loadList() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getStringList('plates') ?? ['MH46DF1352'];
    setState(() => _list = saved.map(PlateReader.clean).where((e) => e.isNotEmpty).toSet());
  }

  Future<void> _saveList(Set<String> plates) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('plates', plates.toList());
    setState(() => _list = plates);
  }

  // ---------------- camera ----------------
  Future<void> _startCamera() async {
    if (cameras.isEmpty) {
      try {
        cameras = await availableCameras();
      } catch (_) {}
    }
    if (cameras.isEmpty) {
      setState(() => _error = 'No camera found.');
      return;
    }
    final back = cameras.firstWhere(
      (c) => c.lensDirection == CameraLensDirection.back,
      orElse: () => cameras.first,
    );
    _camId = back.name;
    CameraController make(int? fps) => CameraController(
          back,
          _set.preset,
          enableAudio: false,
          fps: fps,
          imageFormatGroup: ImageFormatGroup.nv21,
        );
    var cam = make(_set.fps);
    try {
      try {
        await cam.initialize();
      } on CameraException {
        // Some phones refuse a fixed frame rate at this size: let the phone choose.
        await cam.dispose();
        cam = make(null);
        await cam.initialize();
      }
      try {
        await cam.setFocusMode(FocusMode.auto);
      } catch (_) {}
      try {
        if (cam.value.focusPointSupported) await cam.setFocusPoint(const Offset(0.5, 0.5));
      } catch (_) {}
      try {
        if (cam.value.exposurePointSupported) await cam.setExposurePoint(const Offset(0.5, 0.5));
      } catch (_) {}
      try {
        await cam.setFlashMode(FlashMode.off);
      } catch (_) {}
      try {
        _maxZoom = await cam.getMaxZoomLevel();
        final minZoom = await cam.getMinZoomLevel();
        await cam.setZoomLevel(_set.zoom.clamp(minZoom, _maxZoom).toDouble());
      } catch (_) {}
      final ps = cam.value.previewSize;
      _resText = ps == null ? '?' : '${ps.width.round()}x${ps.height.round()}';
      _cam = cam;
      if (mounted) setState(() => _error = null);
      await _applyRotation();
      await _startMode();
      await _shutter.probe(_camId);
      await _applyShutter();
    } on CameraException catch (e) {
      setState(() => _error = 'Camera problem: ${e.description ?? e.code}\n'
          'Allow camera permission in phone Settings and reopen the app.');
    } catch (e) {
      setState(() => _error = 'Camera problem: $e');
    }
  }

  Future<void> _startMode() async {
    final c = _cam;
    if (c == null) return;
    _watchdog?.cancel();
    if (_mode == ScanMode.fast) {
      try {
        if (!c.value.isStreamingImages) await c.startImageStream(_onFrame);
      } catch (e) {
        _noteError('stream: $e');
        _mode = ScanMode.safe;
        return _startMode();
      }
      // If no successful read in 5 seconds, switch to Safe mode automatically.
      final okAtStart = _readsOk;
      _watchdog = Timer(const Duration(seconds: 5), () {
        if (mounted && _mode == ScanMode.fast && _readsOk == okAtStart && !_paused) {
          _switchMode(ScanMode.safe, auto: true);
        }
      });
    } else {
      try {
        if (c.value.isStreamingImages) await c.stopImageStream();
      } catch (_) {}
      _photoLoop();
    }
  }

  Future<void> _switchMode(ScanMode m, {bool auto = false}) async {
    if (m == _mode) return;
    final c = _cam;
    if (c != null && _mode == ScanMode.fast) {
      try {
        if (c.value.isStreamingImages) await c.stopImageStream();
      } catch (_) {}
    }
    setState(() {
      _mode = m;
      if (auto) _lastError = 'Fast mode not working on this phone → switched to Safe mode. $_lastError';
    });
    await _startMode();
  }

  Future<void> _stopCamera() async {
    _watchdog?.cancel();
    final cam = _cam;
    _cam = null;
    if (cam == null) return;
    try {
      if (cam.value.isStreamingImages) await cam.stopImageStream();
    } catch (_) {}
    // let a running photo/read finish
    for (var i = 0; i < 20 && (_inFlight > 0 || _photoLoopRunning); i++) {
      await Future.delayed(const Duration(milliseconds: 50));
    }
    try {
      await cam.dispose();
    } catch (_) {}
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.inactive || state == AppLifecycleState.paused) {
      _stopCamera();
      if (mounted) setState(() {});
    } else if (state == AppLifecycleState.resumed && _cam == null) {
      _startCamera();
    }
  }

  // ---------------- FAST mode: live frames ----------------
  void _onFrame(CameraImage img) {
    _framesIn++;
    if (_framesIn % 30 == 1) _resText = '${img.width}x${img.height}';
    if (_paused || _mode != ScanMode.fast) return;
    final now = DateTime.now().millisecondsSinceEpoch;
    final base = _baseRotation();
    final w = img.width - img.width % 2;
    final h = img.height - img.height % 2;
    final rot = (base + _rotExtra) % 360;
    CropRect rect;
    if (_set.band) {
      final (sw, sh) = _set.bandScreen(_portrait);
      final imageAspect = rot % 180 == 0 ? w / h : h / w; // upright picture
      final (bw, bh) = bandOfImage(imageAspect, _screenAspect, sw, sh);
      rect = bandFor(w, h, rot, bw, bh);
    } else {
      rect = CropRect(0, 0, w, h);
    }
    final y = img.planes[0];

    // Brightness for the fixed-shutter loop (cheap, a few times a second).
    if (now - _lastLumaAt >= 150) {
      _lastLumaAt = now;
      _luma = meanLuma(y.bytes, y.bytesPerRow, rect);
      _exposureStep(now);
    }

    if (!_set.bestFrame) {
      if (_busy) return;
      _inFlight++;
      _processFrame(_Frame(img, 0, now, rect, base)).whenComplete(() => _inFlight--);
      return;
    }

    final score = sharpness(y.bytes, y.bytesPerRow, rect, rowStep: 6);
    _sharp = score;
    final p = _pending;
    if (_busy) {
      // Reader is busy: remember the sharpest recent frame for next time.
      if (p == null || now - p.atMs > _set.pendingMs || score > p.score) {
        _pending = _Frame(img, score, now, rect, base);
      }
      return;
    }
    var use = _Frame(img, score, now, rect, base);
    if (p != null && now - p.atMs <= _set.pendingMs && p.score > score) {
      use = p;
      _bestPicks++;
    }
    _pending = null;
    _inFlight++;
    _processFrame(use).whenComplete(() => _inFlight--);
  }

  Future<void> _processFrame(_Frame f) async {
    final t = DateTime.fromMillisecondsSinceEpoch(f.atMs);
    final sw = Stopwatch()..start();
    try {
      var frame = _frameOf(f.img);
      final r = f.rect;
      if (r.left + r.width <= frame.width && r.top + r.height <= frame.height) {
        frame = cropNv21(frame, r);
      }
      final base = f.baseRot;
      final reader = _takeReader();
      var text = await reader.processImage(_makeInput(frame, base + _rotExtra));
      if (text.blocks.isEmpty) {
        // Nothing found: every 3rd empty frame, try another angle in case
        // the phone reports its orientation differently.
        _emptyFrames++;
        if (_emptyFrames % 3 == 0) {
          final alt = _altRotations[(_emptyFrames ~/ 3) % _altRotations.length];
          final tryExtra = (_rotExtra + alt) % 360;
          final t2 = await reader.processImage(_makeInput(frame, base + tryExtra));
          if (t2.blocks.isNotEmpty) {
            _rotExtra = tryExtra;
            text = t2;
          }
        }
      } else {
        _emptyFrames = 0;
      }
      _afterRead(text, sw, t, _Snap(frame, (base + _rotExtra) % 360));
    } catch (e) {
      _noteError('read: $e');
    }
  }

  // ---------------- fixed fast shutter ----------------
  int get _targetNs => _set.shutter <= 0 ? 0 : 1000000000 ~/ _set.shutter;

  String _shutterText() {
    final e = _exp;
    if (e == null) return _set.shutter <= 0 ? 'auto' : 'auto(${_shutter.status})';
    return '1/${(1e9 / e.exposureNs).round()} ISO${e.iso}';
  }

  Future<void> _applyShutter() async {
    if (_camId.isEmpty) return;
    if (_set.shutter <= 0 || !_shutter.supported) {
      if (_exp != null) await _shutter.auto(_camId);
      _exp = null;
      if (mounted) setState(() {});
      return;
    }
    // Start at the chosen shutter with a middle ISO, then the loop fixes brightness.
    final iso = 400.clamp(_shutter.minIso, _shutter.maxIso).toInt();
    final ns = _targetNs.clamp(_shutter.minNs, _shutter.maxNs).toInt();
    final first = ExposureSetting(ns, iso);
    final ok = await _shutter.manual(_camId, first, _frameNs(ns));
    _exp = ok ? first : null;
    _lastExpAt = DateTime.now().millisecondsSinceEpoch;
    if (!ok) _shutter.supported = false;
    if (mounted) setState(() {});
  }

  int _frameNs(int exposureNs) {
    final perFrame = 1000000000 ~/ (_set.fps <= 0 ? 30 : _set.fps);
    return exposureNs > perFrame ? exposureNs : perFrame;
  }

  void _exposureStep(int now) {
    final cur = _exp;
    if (cur == null || _expBusy || now - _lastExpAt < 300 || _camId.isEmpty) return;
    final target = _targetNs;
    final slowest = _set.fastMode
        ? target * 2
        : (target * 4 < 8000000 ? target * 4 : (target > 8000000 ? target : 8000000));
    final next = nextExposure(
      meanY: _luma,
      current: cur,
      targetNs: target,
      slowestNs: slowest,
      minNs: _shutter.minNs,
      maxNs: _shutter.maxNs,
      minIso: _shutter.minIso,
      maxIso: _shutter.maxIso,
    );
    if (next == null) return;
    _expBusy = true;
    _lastExpAt = now;
    _shutter.manual(_camId, next, _frameNs(next.exposureNs)).then((ok) {
      if (ok) {
        _exp = next;
      } else {
        _exp = null;
        _shutter.supported = false;
      }
    }).whenComplete(() => _expBusy = false);
  }

  int _baseRotation() {
    final c = _cam;
    if (c == null) return 0;
    const orient = {
      DeviceOrientation.portraitUp: 0,
      DeviceOrientation.landscapeLeft: 90,
      DeviceOrientation.portraitDown: 180,
      DeviceOrientation.landscapeRight: 270,
    };
    final dev = orient[c.value.lockedCaptureOrientation ?? c.value.deviceOrientation] ?? 90;
    return rotationFor(c.description.sensorOrientation, dev);
  }

  InputImage _makeInput(Nv21Frame f, int degrees) => InputImage.fromBytes(
        bytes: f.bytes,
        metadata: InputImageMetadata(
          size: Size(f.width.toDouble(), f.height.toDouble()),
          rotation: InputImageRotationValue.fromRawValue(degrees % 360) ??
              InputImageRotation.rotation0deg,
          format: InputImageFormat.nv21,
          bytesPerRow: f.width,
        ),
      );

  Nv21Frame _frameOf(CameraImage img) => toNv21(
        img.width,
        img.height,
        img.planes.map((p) => PlaneData(p.bytes, p.bytesPerRow, p.bytesPerPixel)).toList(),
      );

  // ---------------- SAFE mode: quick photos ----------------
  Future<void> _photoLoop() async {
    if (_photoLoopRunning) return;
    _photoLoopRunning = true;
    try {
      while (mounted && _mode == ScanMode.safe) {
        final c = _cam;
        if (c == null) break;
        if (_paused || !c.value.isInitialized || c.value.isTakingPicture) {
          await Future.delayed(const Duration(milliseconds: 200));
          continue;
        }
        final t = DateTime.now();
        final sw = Stopwatch()..start();
        try {
          final file = await c.takePicture();
          _framesIn++;
          final text = await _recognizer.processImage(InputImage.fromFilePath(file.path));
          _afterRead(text, sw, t);
          File(file.path).delete().catchError((_) => File(file.path));
        } catch (e) {
          _noteError('photo: $e');
          await Future.delayed(const Duration(milliseconds: 400));
        }
      }
    } finally {
      _photoLoopRunning = false;
    }
  }

  // ---------------- shared ----------------
  void _noteError(String e) {
    _errors++;
    _lastError = e.length > 120 ? e.substring(0, 120) : e;
    if (mounted) setState(() {});
  }

  void _afterRead(RecognizedText text, Stopwatch sw, DateTime t, [_Snap? snap]) {
    final cleaned = PlateReader.pieces([
      text.text,
      for (final b in text.blocks) b.text,
      for (final b in text.blocks)
        for (final l in b.lines) l.text,
    ]);
    final plates = PlateReader.plates(cleaned);
    final hits = PlateReader.listHits(cleaned, plates, _list);
    sw.stop();

    _readsOk++;
    _rateCount++;
    final now = DateTime.now();
    final elapsed = now.difference(_rateStart).inMilliseconds;
    if (elapsed >= 1000) {
      _readsPerSec = _rateCount * 1000 / elapsed;
      _rateCount = 0;
      _rateStart = now;
    }
    for (final p in plates) {
      _allSeen.add(p);
      _recent.remove(p);
      _recent.insert(0, p);
      if (_recent.length > 6) _recent.removeLast();
    }
    for (final h in hits) {
      _confirm(h, t, snap);
    }
    if (_set.voting && _mode == ScanMode.fast) {
      final agreed = _voter.add(plates, t.millisecondsSinceEpoch);
      for (final a in agreed) {
        if (!_list.contains(a) || hits.contains(a)) continue;
        // Several reads, each slightly wrong, agree on a listed plate.
        final mute = _muteUntil[a];
        if (mute != null && t.isBefore(mute)) continue;
        _voteFixes++;
        _muteUntil[a] = DateTime.now().add(const Duration(seconds: 30));
        _fireAlert(a, _lastMs, snap);
      }
    }
    if (!mounted) return;
    setState(() {
      _lastMs = sw.elapsedMilliseconds;
      if (_bestMs == 0 || _lastMs < _bestMs) _bestMs = _lastMs;
      final raw = text.text.replaceAll('\n', ' ').trim();
      if (raw.isNotEmpty) _rawText = raw.length > 60 ? raw.substring(0, 60) : raw;
    });
  }

  void _confirm(String p, DateTime t, [_Snap? snap]) {
    final mute = _muteUntil[p];
    if (mute != null && t.isBefore(mute)) return;
    final need = _mode == ScanMode.fast ? 2 : 1; // safe mode is slower, 1 clear read is enough
    final s = _sightings.putIfAbsent(p, () => []);
    s.removeWhere((x) => t.difference(x).inMilliseconds > 3000);
    if (s.isEmpty) _firstSeen[p] = t;
    s.add(t);
    if (s.length >= need) {
      final delayMs = DateTime.now().difference(_firstSeen[p]!).inMilliseconds + _lastMs;
      _muteUntil[p] = DateTime.now().add(const Duration(seconds: 30));
      s.clear();
      _fireAlert(p, delayMs, snap);
    }
  }

  Future<void> _fireAlert(String p, int delayMs, [_Snap? snap]) async {
    final time = TimeOfDay.now().format(context);
    final info = _AlertInfo(MatchRecord(p, DateTime.now()));
    setState(() {
      _alert = true;
      _alertPlate = p;
      _alertInfo = info;
      _matchLog.insert(0, '$p   $time   caught in ${(delayMs / 1000).toStringAsFixed(2)}s');
    });
    // 1) sound + vibration straight away
    try {
      await _player.stop();
      await _player.play(AssetSource('beep.wav'), volume: 1.0);
    } catch (_) {}
    try {
      if (await Vibration.hasVibrator() == true) {
        Vibration.vibrate(duration: 1200);
      }
    } catch (_) {
      HapticFeedback.heavyImpact();
    }
    // 2) voice after the beep
    if (_set.voice) {
      Timer(const Duration(milliseconds: 900), () => Native.speak('Match. ${spokenPlate(p)}'));
    }
    // 3) photo of the car + GPS, saved as evidence
    if (snap != null) {
      try {
        info.photo = await _toImage(snap);
        info.quarterTurns = (snap.rot % 360) ~/ 90;
        if (mounted) setState(() {});
      } catch (e) {
        _noteError('photo: $e');
      }
    }
    unawaited(_saveEvidence(info));
    _alertTimer?.cancel();
    _alertTimer = Timer(const Duration(seconds: 12), () {
      if (mounted) setState(() => _alert = false);
    });
  }

  Future<ui.Image> _toImage(_Snap s) {
    final step = s.frame.width > 1200 ? 2 : 1;
    final (rgba, w, h) = nv21ToRgba(s.frame, step: step);
    final c = Completer<ui.Image>();
    ui.decodeImageFromPixels(rgba, w, h, ui.PixelFormat.rgba8888, c.complete);
    return c.future;
  }

  Future<Uint8List> _uprightPng(ui.Image img, int quarterTurns) async {
    final turns = quarterTurns % 4;
    final w = turns.isOdd ? img.height : img.width;
    final h = turns.isOdd ? img.width : img.height;
    final rec = ui.PictureRecorder();
    final canvas = Canvas(rec);
    canvas.translate(w / 2, h / 2);
    canvas.rotate(turns * math.pi / 2);
    canvas.translate(-img.width / 2, -img.height / 2);
    canvas.drawImage(img, Offset.zero, Paint());
    final out = await rec.endRecording().toImage(w, h);
    final bd = await out.toByteData(format: ui.ImageByteFormat.png);
    return bd!.buffer.asUint8List();
  }

  Future<void> _saveEvidence(_AlertInfo info) async {
    final r = info.rec;
    try {
      final dir = Directory('${await Native.filesDir()}/matches');
      await dir.create(recursive: true);
      final img = info.photo;
      if (img != null) {
        final f = File('${dir.path}/${r.time.millisecondsSinceEpoch}_${r.plate}.png');
        await f.writeAsBytes(await _uprightPng(img, info.quarterTurns));
        r.photo = f.path;
      }
    } catch (e) {
      _noteError('save photo: $e');
    }
    final pos = await _position();
    r.lat = pos?.latitude;
    r.lng = pos?.longitude;
    _log.insert(0, r);
    await _saveLog();
    if (mounted) setState(() {});
  }

  // ---------------- location ----------------
  Future<Position?> _position({bool ask = false}) async {
    try {
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied && ask) perm = await Geolocator.requestPermission();
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) return null;
      if (ask) return null; // only asking for permission now
      if (!await Geolocator.isLocationServiceEnabled()) return null;
      try {
        return await Geolocator.getCurrentPosition(
          locationSettings: const LocationSettings(
            accuracy: LocationAccuracy.high,
            timeLimit: Duration(seconds: 6),
          ),
        );
      } catch (_) {
        return await Geolocator.getLastKnownPosition();
      }
    } catch (_) {
      return null;
    }
  }

  // ---------------- match log (evidence) ----------------
  Future<File> _logFile() async => File('${await Native.filesDir()}/matches.json');

  Future<void> _loadLog() async {
    try {
      final f = await _logFile();
      if (!await f.exists()) return;
      final list = jsonDecode(await f.readAsString()) as List<dynamic>;
      _log
        ..clear()
        ..addAll(list.map((e) => MatchRecord.fromJson(e as Map<String, dynamic>)));
      if (mounted) setState(() {});
    } catch (e) {
      _noteError('log: $e');
    }
  }

  Future<void> _saveLog() async {
    try {
      final f = await _logFile();
      await f.writeAsString(jsonEncode(_log.map((e) => e.toJson()).toList()));
    } catch (e) {
      _noteError('log: $e');
    }
  }

  Future<void> _share(MatchRecord r) async {
    try {
      final photo = r.photo;
      final files = (photo != null && File(photo).existsSync()) ? [XFile(photo)] : null;
      await SharePlus.instance.share(ShareParams(text: r.shareText, files: files));
    } catch (e) {
      _snack('Could not share: $e');
    }
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  // ---------------- list import ----------------
  Future<void> _importList() async {
    try {
      final cells = await Native.pickList();
      if (cells == null) return;
      final r = importPlates(cells);
      if (!mounted) return;
      if (r.plates.isEmpty) {
        _snack('No number plates found in that file (${r.cells} cells checked).');
        return;
      }
      final choice = await showDialog<String>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text('Found ${r.plates.length} plates'),
          content: Text('Checked ${r.cells} cells in the file.\n'
              'You have ${_list.length} plates on your list now.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
            TextButton(onPressed: () => Navigator.pop(ctx, 'add'), child: const Text('Add to list')),
            FilledButton(onPressed: () => Navigator.pop(ctx, 'replace'), child: const Text('Replace list')),
          ],
        ),
      );
      if (choice == null) return;
      final next = choice == 'replace' ? r.plates : {..._list, ...r.plates};
      await _saveList(next);
      _muteUntil.clear();
      _snack('List now has ${next.length} plates.');
    } catch (e) {
      _snack('Could not read the file: $e');
    }
  }

  // ---------------- screen rotation ----------------
  Future<void> _applyRotation() async {
    final c = _cam;
    switch (_set.rotation) {
      case 1:
        await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
        try {
          await c?.lockCaptureOrientation(DeviceOrientation.portraitUp);
        } catch (_) {}
      case 2:
        await SystemChrome.setPreferredOrientations(
            [DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
        try {
          await c?.unlockCaptureOrientation();
        } catch (_) {}
      default:
        await SystemChrome.setPreferredOrientations([
          DeviceOrientation.portraitUp,
          DeviceOrientation.landscapeLeft,
          DeviceOrientation.landscapeRight,
        ]);
        try {
          await c?.unlockCaptureOrientation();
        } catch (_) {}
    }
  }

  void _reset() {
    setState(() {
      _recent.clear();
      _allSeen.clear();
      _sightings.clear();
      _firstSeen.clear();
      _muteUntil.clear();
      _matchLog.clear();
      _bestMs = 0;
      _bestPicks = 0;
      _voteFixes = 0;
      _voter.clear();
      _errors = 0;
      _lastError = '';
      _rawText = '';
    });
  }

  Future<void> _editList() async {
    final result = await Navigator.of(context).push<Set<String>>(
      MaterialPageRoute(builder: (_) => ListEditorPage(initial: _list)),
    );
    if (result != null) {
      await _saveList(result);
      _muteUntil.clear();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _alertTimer?.cancel();
    _watchdog?.cancel();
    _heartbeat?.cancel();
    _stopCamera();
    for (final r in _recognizers) {
      r.close();
    }
    _player.dispose();
    WakelockPlus.disable();
    super.dispose();
  }

  // ---------------- UI: Rider screen ----------------
  @override
  Widget build(BuildContext context) {
    final cam = _cam;
    return Scaffold(
      backgroundColor: Colors.black,
      body: LayoutBuilder(builder: (ctx, box) {
        _portrait = box.maxHeight > box.maxWidth;
        if (box.maxHeight > 0) _screenAspect = box.maxWidth / box.maxHeight;
        final (bandW, bandH) = _set.bandScreen(_portrait);
        final info = _alertInfo;
        return Stack(
          children: [
            Positioned.fill(
              child: (cam != null && cam.value.isInitialized)
                  ? _fullPreview(cam)
                  : Center(
                      child: Padding(
                        padding: const EdgeInsets.all(24),
                        child: Text(_error ?? 'Starting camera…',
                            textAlign: TextAlign.center, style: const TextStyle(fontSize: 18)),
                      ),
                    ),
            ),
            if (_set.band && _mode == ScanMode.fast && _set.area != 2)
              IgnorePointer(
                child: Center(
                  child: FractionallySizedBox(
                    widthFactor: bandW,
                    heightFactor: bandH,
                    child: Container(
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.greenAccent.withOpacity(0.85), width: 2),
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ),
              ),
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              child: SafeArea(
                child: Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Center(child: _statusPill()),
                ),
              ),
            ),
            if (_set.details)
              Positioned(
                top: 0,
                left: 0,
                child: SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(10, 56, 10, 0),
                    child: _detailsPanel(),
                  ),
                ),
              ),
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: SafeArea(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(12, 0, 12, 10),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _recentRow(),
                      const SizedBox(height: 8),
                      _buttonRow(),
                    ],
                  ),
                ),
              ),
            ),
            if (_alert && info != null) Positioned.fill(child: _alertView(info)),
          ],
        );
      }),
    );
  }

  /// Camera picture filling the whole screen (edges cut off, no black bars).
  Widget _fullPreview(CameraController cam) {
    final ar = cam.value.aspectRatio; // sideways width / height
    final previewAspect = _portrait ? 1 / ar : ar;
    return ClipRect(
      child: FittedBox(
        fit: BoxFit.cover,
        child: SizedBox(
          width: 1000 * previewAspect,
          height: 1000,
          child: CameraPreview(cam),
        ),
      ),
    );
  }

  String _shutterShort() {
    final e = _exp;
    if (e == null) return 'auto shutter';
    return '1/${(1e9 / e.exposureNs).round()}';
  }

  Widget _statusPill() {
    String text;
    Color dot;
    if (_cam == null) {
      text = _error == null ? 'Starting camera…' : 'Camera problem – open Menu';
      dot = Colors.redAccent;
    } else if (_paused) {
      text = 'Paused';
      dot = Colors.orange;
    } else if (_list.isEmpty) {
      text = 'List is empty – Menu › Import list';
      dot = Colors.orange;
    } else {
      text = '${_set.fastMode ? 'Fast traffic' : 'Scanning'} · '
          '${_readsPerSec.toStringAsFixed(0)}/s · ${_shutterShort()} · ${_list.length} on list';
      dot = Colors.greenAccent;
    }
    return GestureDetector(
      onTap: () async {
        setState(() => _set.details = !_set.details);
        await _set.save();
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.55),
          borderRadius: BorderRadius.circular(30),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 12,
              height: 12,
              decoration: BoxDecoration(color: dot, shape: BoxShape.circle),
            ),
            const SizedBox(width: 8),
            Flexible(
              child: Text(text,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _detailsPanel() => Container(
        width: 300,
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.6),
          borderRadius: BorderRadius.circular(10),
        ),
        child: DefaultTextStyle(
          style: const TextStyle(fontSize: 12, color: Colors.white70),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _big('$_lastMs ms', 'one read'),
              _big(_readsPerSec.toStringAsFixed(1), 'checks / second'),
              Text('${_set.fastMode ? 'FAST TRAFFIC' : 'PARKED'} · ${_mode == ScanMode.fast ? 'live video' : 'safe (photos)'}'),
              Text('Camera $_resText · ${_set.fps} fps · zoom ${_set.zoom}x · readers ${_set.readers}'),
              Text('Shutter ${_shutterText()}'),
              Text('Sharpness ${_sharp.toStringAsFixed(0)} · brightness ${_luma.toStringAsFixed(0)}'),
              Text('Sharp picks $_bestPicks · vote fixes $_voteFixes'),
              Text('Frames $_framesIn · reads $_readsOk · errors $_errors'),
              if (_lastError.isNotEmpty) Text('Last error: $_lastError', maxLines: 3),
              Text('Text seen: ${_rawText.isEmpty ? '—' : _rawText}', maxLines: 2),
              const SizedBox(height: 4),
              const Text('Tap the top bar to hide', style: TextStyle(color: Colors.white38)),
            ],
          ),
        ),
      );

  Widget _recentRow() {
    if (_recent.isEmpty) return const SizedBox.shrink();
    return Wrap(
      spacing: 8,
      runSpacing: 6,
      alignment: WrapAlignment.center,
      children: [
        for (final p in _recent.take(3))
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: (_list.contains(p) ? Colors.red : Colors.black).withOpacity(0.6),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(prettyPlate(p),
                style: const TextStyle(fontFamily: 'monospace', fontSize: 16, fontWeight: FontWeight.w600)),
          ),
      ],
    );
  }

  Widget _bigButton(IconData icon, String label, VoidCallback onTap, {bool strong = false}) => Expanded(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 5),
          child: SizedBox(
            height: 62,
            child: strong
                ? FilledButton.icon(
                    onPressed: onTap,
                    icon: Icon(icon, size: 26),
                    label: Text(label, style: const TextStyle(fontSize: 17)))
                : FilledButton.tonalIcon(
                    onPressed: onTap,
                    icon: Icon(icon, size: 26),
                    label: Text(label, style: const TextStyle(fontSize: 17))),
          ),
        ),
      );

  Widget _buttonRow() => Row(
        children: [
          _bigButton(_paused ? Icons.play_arrow : Icons.pause, _paused ? 'Resume' : 'Pause',
              () => setState(() => _paused = !_paused),
              strong: _paused),
          _bigButton(_set.fastMode ? Icons.speed : Icons.local_parking,
              _set.fastMode ? 'Fast' : 'Parked', _toggleFast),
          _bigButton(Icons.menu, 'Menu', _openSettings),
        ],
      );

  Widget _alertView(_AlertInfo info) {
    final photo = info.photo;
    final r = info.rec;
    return GestureDetector(
      onTap: () {},
      child: Container(
        color: Colors.red.shade800.withOpacity(0.94),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                const Text('DEFAULTER MATCH',
                    style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, letterSpacing: 2)),
                FittedBox(
                  child: Text(prettyPlate(r.plate),
                      style: const TextStyle(
                          fontSize: 64, fontWeight: FontWeight.w900, fontFamily: 'monospace')),
                ),
                Text(r.timeText, style: const TextStyle(fontSize: 16)),
                const SizedBox(height: 8),
                Expanded(
                  child: photo == null
                      ? const Center(child: Text('Saving photo…'))
                      : ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: RotatedBox(
                            quarterTurns: info.quarterTurns,
                            child: RawImage(image: photo, fit: BoxFit.contain),
                          ),
                        ),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    _bigButton(Icons.send, 'Send to office', () => _share(r), strong: true),
                    _bigButton(Icons.close, 'Close', () {
                      _alertTimer?.cancel();
                      setState(() => _alert = false);
                    }),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ---------------- one-tap modes ----------------
  Future<void> _toggleFast() async {
    if (_set.fastMode) {
      _set.applyParked();
    } else {
      _set.applyFast();
    }
    await _set.save();
    await _restartCamera();
  }

  Future<void> _restartCamera() async {
    _exp = null;
    _pending = null;
    await _stopCamera();
    if (mounted) setState(() {});
    await _startCamera();
  }

  Future<void> _openLog() async {
    await Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => MatchLogPage(log: _log, onShare: _share, onClear: () async {
        _log.clear();
        await _saveLog();
        if (mounted) setState(() {});
      }),
    ));
  }

  // ---------------- Menu (settings) ----------------
  Future<void> _openSettings() async {
    final shutterNote = _shutter.supported ? '' : '  (${_shutter.status})';
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) {
          Future<void> change(Future<void> Function() action) async {
            await action();
            await _set.save();
            if (ctx.mounted) setSheet(() {});
            if (mounted) setState(() {});
          }

          Widget head(String t) => Padding(
                padding: const EdgeInsets.fromLTRB(0, 14, 0, 4),
                child: Text(t,
                    style: const TextStyle(
                        fontSize: 13, fontWeight: FontWeight.bold, color: Colors.amber, letterSpacing: 1)),
              );

          Widget row(String title, String help, Widget control) {
            final label = Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
                Text(help, style: const TextStyle(fontSize: 11, color: Colors.white60)),
              ],
            );
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: _portrait
                  ? Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      label,
                      const SizedBox(height: 6),
                      SingleChildScrollView(scrollDirection: Axis.horizontal, child: control),
                    ])
                  : Row(children: [
                      SizedBox(width: 230, child: label),
                      Expanded(
                          child: SingleChildScrollView(scrollDirection: Axis.horizontal, child: control)),
                    ]),
            );
          }

          SegmentedButton<T> seg<T>(T value, Map<T, String> options, void Function(T) onPick) =>
              SegmentedButton<T>(
                showSelectedIcon: false,
                segments: [
                  for (final e in options.entries) ButtonSegment<T>(value: e.key, label: Text(e.value)),
                ],
                selected: {value},
                onSelectionChanged: (v) => onPick(v.first),
              );

          Widget action(IconData icon, String label, Future<void> Function() onTap) => Padding(
                padding: const EdgeInsets.only(right: 8, bottom: 8),
                child: FilledButton.tonalIcon(
                  onPressed: () async {
                    Navigator.pop(ctx);
                    await onTap();
                  },
                  icon: Icon(icon),
                  label: Text(label),
                ),
              );

          return SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  head('DEFAULTER LIST  ·  ${_list.length} plates'),
                  Wrap(children: [
                    action(Icons.upload_file, 'Import Excel / CSV', _importList),
                    action(Icons.edit_note, 'Type / edit plates', _editList),
                    action(Icons.history, 'Match log (${_log.length})', _openLog),
                  ]),
                  head('SCREEN'),
                  row('Hold the phone', 'Upright suits most bike mounts',
                      seg<int>(_set.rotation, {0: 'Auto', 1: 'Upright', 2: 'Sideways'}, (v) => change(() async {
                            _set.rotation = v;
                            await _applyRotation();
                          }))),
                  row('Reading area', 'Bigger = sees more, reads a bit slower',
                      seg<int>(_set.area, {0: 'Normal', 1: 'Tall', 2: 'Full screen'}, (v) => change(() async {
                            _set.area = v;
                            _set.band = true;
                            _pending = null;
                          }))),
                  row('Voice alert', 'Says the plate out loud on a match',
                      seg<bool>(_set.voice, {true: 'On', false: 'Off'}, (v) => change(() async {
                            _set.voice = v;
                          }))),
                  row('Show all numbers', 'For testing (or tap the top bar)',
                      seg<bool>(_set.details, {false: 'Off', true: 'On'}, (v) => change(() async {
                            _set.details = v;
                          }))),
                  head('CAMERA'),
                  row(
                    'Shutter speed$shutterNote',
                    '1/x seconds. Faster = less blur. Fast cars need 1/2000+',
                    seg<int>(_set.shutter,
                        {0: 'Auto', 250: '250', 500: '500', 1000: '1000', 2000: '2000', 4000: '4000'},
                        (v) => change(() async {
                              _set.shutter = v;
                              await _applyShutter();
                            })),
                  ),
                  row(
                    'Zoom (max ${_maxZoom.toStringAsFixed(1)}x)',
                    'More zoom = reads farther, sees less road',
                    seg<double>(_set.zoom, {1.0: '1x', 1.5: '1.5x', 2.0: '2x', 3.0: '3x', 5.0: '5x'},
                        (v) => change(() async {
                              _set.zoom = v;
                              try {
                                await _cam?.setZoomLevel(v.clamp(1.0, _maxZoom).toDouble());
                              } catch (_) {}
                            })),
                  ),
                  row(
                    'Picture size',
                    '4K = 2x more detail than 1080p (flagships only)',
                    seg<int>(_set.res, {720: '720p', 1080: '1080p', 2160: '4K'}, (v) => change(() async {
                          _set.res = v;
                          await _restartCamera();
                        })),
                  ),
                  row(
                    'Frames per second',
                    '60 = more chances per car (needs a good phone)',
                    seg<int>(_set.fps, {30: '30', 60: '60'}, (v) => change(() async {
                          _set.fps = v;
                          await _restartCamera();
                        })),
                  ),
                  row(
                    'Readers at once',
                    '2 = twice the reads per second on fast phones',
                    seg<int>(_set.readers, {1: '1', 2: '2'}, (v) => change(() async {
                          _set.readers = v;
                        })),
                  ),
                  row(
                    'Pick sharpest frame',
                    'Skips blurry frames while reading',
                    seg<bool>(_set.bestFrame, {true: 'On', false: 'Off'}, (v) => change(() async {
                          _set.bestFrame = v;
                          _pending = null;
                        })),
                  ),
                  row(
                    'Combine reads (voting)',
                    'Fixes single wrong letters using 3+ reads',
                    seg<bool>(_set.voting, {true: 'On', false: 'Off'}, (v) => change(() async {
                          _set.voting = v;
                          _voter.clear();
                        })),
                  ),
                  head('MORE'),
                  Wrap(children: [
                    action(Icons.swap_horiz, _mode == ScanMode.fast ? 'Use Safe mode' : 'Use Fast mode',
                        () => _switchMode(_mode == ScanMode.fast ? ScanMode.safe : ScanMode.fast)),
                    action(Icons.refresh, 'Reset counters', () async => _reset()),
                  ]),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _big(String value, String label) => Padding(
        padding: const EdgeInsets.only(bottom: 4),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white)),
            const SizedBox(width: 6),
            Flexible(child: Text(label)),
          ],
        ),
      );
}

// ------------------------------------------------------------------
// Match log: every match with photo, time and map link
// ------------------------------------------------------------------
class MatchLogPage extends StatefulWidget {
  final List<MatchRecord> log;
  final Future<void> Function(MatchRecord) onShare;
  final Future<void> Function() onClear;
  const MatchLogPage({super.key, required this.log, required this.onShare, required this.onClear});

  @override
  State<MatchLogPage> createState() => _MatchLogPageState();
}

class _MatchLogPageState extends State<MatchLogPage> {
  @override
  Widget build(BuildContext context) {
    final log = widget.log;
    return Scaffold(
      appBar: AppBar(
        title: Text('Match log (${log.length})'),
        actions: [
          if (log.isNotEmpty)
            TextButton(
              onPressed: () async {
                final ok = await showDialog<bool>(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    title: const Text('Delete all matches?'),
                    content: const Text('Photos and locations will be removed from this phone.'),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
                      FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete')),
                    ],
                  ),
                );
                if (ok == true) {
                  for (final r in log) {
                    final ph = r.photo;
                    if (ph != null) {
                      try {
                        File(ph).deleteSync();
                      } catch (_) {}
                    }
                  }
                  await widget.onClear();
                  if (mounted) setState(() {});
                }
              },
              child: const Text('Delete all'),
            ),
        ],
      ),
      body: log.isEmpty
          ? const Center(child: Text('No matches yet.'))
          : ListView.separated(
              itemCount: log.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (ctx, i) {
                final r = log[i];
                final ph = r.photo;
                return ListTile(
                  leading: (ph != null && File(ph).existsSync())
                      ? ClipRRect(
                          borderRadius: BorderRadius.circular(6),
                          child: Image.file(File(ph), width: 72, height: 54, fit: BoxFit.cover),
                        )
                      : const Icon(Icons.directions_car, size: 40),
                  title: Text(prettyPlate(r.plate),
                      style: const TextStyle(fontFamily: 'monospace', fontWeight: FontWeight.bold)),
                  subtitle: Text('${r.timeText}${r.lat == null ? '' : '\n${r.lat!.toStringAsFixed(5)}, ${r.lng!.toStringAsFixed(5)}'}'),
                  isThreeLine: r.lat != null,
                  trailing: IconButton(
                    icon: const Icon(Icons.send),
                    tooltip: 'Send to office',
                    onPressed: () => widget.onShare(r),
                  ),
                );
              },
            ),
    );
  }
}

// ------------------------------------------------------------------
// Test list editor – type or paste plates, one per line
// ------------------------------------------------------------------
class ListEditorPage extends StatefulWidget {
  final Set<String> initial;
  const ListEditorPage({super.key, required this.initial});

  @override
  State<ListEditorPage> createState() => _ListEditorPageState();
}

class _ListEditorPageState extends State<ListEditorPage> {
  late final TextEditingController _ctrl =
      TextEditingController(text: widget.initial.join('\n'));

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _save() {
    final plates = _ctrl.text
        .split(RegExp(r'[\n,;]'))
        .map(PlateReader.clean)
        .where((e) => e.length >= 6)
        .toSet();
    Navigator.of(context).pop(plates);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Test list (one plate per line)'),
        actions: [
          TextButton.icon(onPressed: _save, icon: const Icon(Icons.check), label: const Text('Save')),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: TextField(
          controller: _ctrl,
          maxLines: null,
          expands: true,
          textCapitalization: TextCapitalization.characters,
          style: const TextStyle(fontFamily: 'monospace', fontSize: 18),
          decoration: const InputDecoration(
            border: OutlineInputBorder(),
            hintText: 'MH46DF1352\nMH04AB1234',
          ),
        ),
      ),
    );
  }
}
