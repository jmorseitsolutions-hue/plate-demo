#!/usr/bin/env bash
# Runs on the Android emulator during the GitHub build.
# Every step has a time limit, so a frozen emulator can never block the build for an hour.
set -u -o pipefail
PKG=com.apexmobilelabs.plate_demo
SUM=${GITHUB_STEP_SUMMARY:-/dev/null}
ENVF=${GITHUB_ENV:-/dev/null}
T_TEST=${T_TEST:-900}      # seconds allowed for the plate-reading test
T_INSTALL=${T_INSTALL:-240}
T_RUN=${T_RUN:-35}
status=passed
fail=0
echo "## Phone (emulator) tests" >> "$SUM"
timeout 180 adb wait-for-device || true

run_pipeline() {
  timeout --kill-after=30 "$T_TEST" flutter test integration_test/plate_pipeline_test.dart -d emulator-5554 2>&1 | tee pipeline.log
  return "${PIPESTATUS[0]}"
}

# 1) Plate reading pipeline (Google reader + our rules, all frame layouts)
run_pipeline; rc=$?
if [ "$rc" -eq 124 ] || [ "$rc" -eq 137 ]; then
  echo "- Plate reading test froze; restarting adb and trying once more" >> "$SUM"
  adb kill-server >/dev/null 2>&1 || true
  timeout 60 adb start-server >/dev/null 2>&1 || true
  timeout 180 adb wait-for-device || true
  run_pipeline; rc=$?
fi
if [ "$rc" -eq 0 ]; then
  echo "- Plate reading test: **PASS**" >> "$SUM"
elif [ "$rc" -eq 124 ] || [ "$rc" -eq 137 ]; then
  status=skipped
  echo "- Plate reading test: **SKIPPED** - the GitHub emulator froze twice (machine problem, not an app problem)" >> "$SUM"
else
  echo "- Plate reading test: **FAIL**" >> "$SUM"; fail=1
fi
grep -o "RESULT.*" pipeline.log | sed 's/^/    /' >> "$SUM" || true
grep -E "Expected|Actual|Exception|Error:" pipeline.log | head -20 | sed 's/^/    /' >> "$SUM" || true

# 2) The real release app, using the emulator's camera
timeout 60 adb uninstall "$PKG" >/dev/null 2>&1 || true
if timeout "$T_INSTALL" adb install -r build/app/outputs/flutter-apk/app-release.apk; then
  timeout 30 adb shell pm grant "$PKG" android.permission.CAMERA || true
  timeout 30 adb logcat -c || true
  timeout 30 adb shell monkey -p "$PKG" -c android.intent.category.LAUNCHER 1 >/dev/null || true
  sleep "$T_RUN"
  timeout 60 adb logcat -d > release.log 2>/dev/null || true
  last=$(grep -o "PLATEALERT_STATS.*" release.log | tail -1)
  echo "- Release app with live camera: \`${last:-no stats line}\`" >> "$SUM"
  reads=$(echo "$last" | sed -n 's/.*reads=\([0-9]*\).*/\1/p')
  native=$(echo "$last" | sed -n 's/.*native=\([^ ]*\).*/\1/p')
  shutter=$(echo "$last" | sed -n 's/.*shutter=\([^ ]*\( ISO[0-9]*\)\{0,1\}\).*/\1/p')
  echo "- Fixed-shutter control on emulator: \`${native:-unknown}\` (shutter now: \`${shutter:-?}\`)" >> "$SUM"
  grep -o "PLATEALERT_STATS.*" release.log | tail -3 | sed 's/^/    /' >> "$SUM" || true
  if [ -n "$reads" ] && [ "$reads" -gt 0 ]; then
    echo "- Live camera scan test: **PASS**" >> "$SUM"
  elif [ -z "$last" ] && ! grep -qE "FATAL EXCEPTION|AndroidRuntime" release.log; then
    # no app output at all and no crash: emulator too slow to start the app in time
    [ "$status" = passed ] && status=skipped
    echo "- Live camera scan test: **SKIPPED** - emulator did not start the app in time" >> "$SUM"
  else
    echo "- Live camera scan test: **FAIL**" >> "$SUM"; fail=1
    grep -E "AndroidRuntime|FATAL|Exception|flutter" release.log | head -40 | sed 's/^/    /' >> "$SUM" || true
  fi
else
  [ "$status" = passed ] && status=skipped
  echo "- Live camera scan test: **SKIPPED** - app install timed out on the emulator" >> "$SUM"
fi

echo "DEVICE_TEST=$status" >> "$ENVF"
echo "Device test result: $status (fail=$fail)"
exit $fail
