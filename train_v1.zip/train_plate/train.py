"""Self-running plate-model training. Run on GitHub Actions on a schedule.

Each run: get data (pinned version) -> resume from the last run -> train for a fixed
time -> score -> keep the best model -> export it for the phone (ONNX).
Everything important is printed as GitHub annotations so it is visible on the public run page.
"""
import argparse
import hashlib
import json
import math
import os
import random
import sys
import time
import urllib.request

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from data import SIZE, extract_coco_zip, letterbox, load_rgb, make_sample  # noqa: E402
from model import PlateNet, loss_fn  # noqa: E402
from post import mask_to_boxes, prf, score_image  # noqa: E402
from synth import paste_plate  # noqa: E402

DATASET = 'keremberke/license-plate-object-detection'
REV = '62d190d43a2275439526444d1cd520b4c478adbd'  # pinned: content can never change under us
SPLITS = ('train', 'valid', 'test')
TOTAL_EPOCHS = 100
BATCH = 32
BASE_LR = 2e-3
VAL_LIMIT = 700
VAL_IN_LIMIT = 400


def note(msg, title='Training'):
    print(f'::notice title={title}::{msg}', flush=True)


def download(data_dir, models_dir):
    """Download the pinned dataset once; remember file fingerprints to detect any tampering."""
    os.makedirs(data_dir, exist_ok=True)
    hashes_path = os.path.join(models_dir, 'data_hashes.json')
    known = json.load(open(hashes_path)) if os.path.exists(hashes_path) else {}
    items = {}
    for split in SPLITS:
        zp = os.path.join(data_dir, f'{split}.zip')
        if not os.path.exists(zp):
            url = f'https://huggingface.co/datasets/{DATASET}/resolve/{REV}/data/{split}.zip'
            print('downloading', url, flush=True)
            urllib.request.urlretrieve(url, zp + '.part')
            os.replace(zp + '.part', zp)
        h = hashlib.sha256(open(zp, 'rb').read()).hexdigest()
        if split in known and known[split] != h:
            raise RuntimeError(f'{split}.zip fingerprint changed ({h}) - refusing to train on it')
        known[split] = h
        items[split] = extract_coco_zip(zp, os.path.join(data_dir, split))
        print(split, len(items[split]), 'images', flush=True)
    json.dump(known, open(hashes_path, 'w'), indent=1)
    return items


class TrainSet(Dataset):
    def __init__(self, items, synth_prob=0.5):
        self.items = items
        self.synth_prob = synth_prob

    def __len__(self):
        return len(self.items)

    def __getitem__(self, i):
        rng = random.Random((torch.initial_seed() + i * 7919) % (1 << 31))
        path, boxes = self.items[i]
        img, mask, _ = make_sample(load_rgb(path), boxes, rng, train=True, synth_prob=self.synth_prob)
        return torch.from_numpy(img).permute(2, 0, 1).float(), torch.from_numpy(mask)[None]


def build_eval(items, limit, indian, seed):
    """Fixed evaluation set: (images uint8 N x 384 x 384 x 3, list of box lists)."""
    rng = random.Random(seed)
    imgs, gts = [], []
    for path, boxes in items[:limit]:
        img = load_rgb(path)
        if indian and boxes:
            new = []
            for b in boxes:
                img, nb = paste_plate(rng, img, b)
                new.append(list(nb))
            boxes = new
        lb, s, (dx, dy) = letterbox(img)
        imgs.append(lb)
        gts.append([[x * s + dx, y * s + dy, w * s, h * s] for x, y, w, h in boxes])
    return np.stack(imgs), gts


@torch.no_grad()
def evaluate(model, data, thr=0.5):
    imgs, gts = data
    model.eval()
    tp = fp = fn = 0
    for k in range(0, len(imgs), 32):
        x = torch.from_numpy(imgs[k:k + 32]).permute(0, 3, 1, 2).float()
        logits = model(x)[:, 0].numpy()
        for j in range(logits.shape[0]):
            a, b, c = score_image(mask_to_boxes(logits[j], thr=thr), gts[k + j])
            tp, fp, fn = tp + a, fp + b, fn + c
    model.train()
    return prf(tp, fp, fn)


def export_onnx(model, path):
    import onnxruntime as ort
    model.eval()
    dummy = torch.randint(0, 256, (1, 3, SIZE, SIZE)).float()
    torch.onnx.export(model, dummy, path, input_names=['image'], output_names=['mask'], opset_version=17)
    ref = model(dummy).numpy()
    out = ort.InferenceSession(path, providers=['CPUExecutionProvider']).run(None, {'image': dummy.numpy()})[0]
    diff = float(np.abs(out - ref).max())
    model.train()
    if diff > 1e-2:
        raise RuntimeError(f'ONNX export differs from PyTorch by {diff}')
    return diff


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--data', default=os.path.expanduser('~/plate_data'))
    ap.add_argument('--models', default='models')
    ap.add_argument('--minutes', type=float, default=300)
    args = ap.parse_args()
    t0 = time.time()
    torch.set_num_threads(os.cpu_count() or 4)
    os.makedirs(args.models, exist_ok=True)

    state_path = os.path.join(args.models, 'last.pt')
    hist_path = os.path.join(args.models, 'metrics.json')
    history = json.load(open(hist_path)) if os.path.exists(hist_path) else {'runs': [], 'epochs': []}
    model = PlateNet(pretrained=not os.path.exists(state_path))
    epoch, best = 0, -1.0
    if os.path.exists(state_path):
        st = torch.load(state_path, map_location='cpu', weights_only=True)
        model.load_state_dict(st['model'])
        epoch, best = int(st['epoch']), float(st['best'])
        note(f'Resuming from epoch {epoch} (best score so far {best:.3f})')
    if epoch >= TOTAL_EPOCHS:
        note(f'Training finished ({epoch} epochs). Best score {best:.3f}. Nothing to do.')
        return

    items = download(args.data, args.models)
    val = build_eval(items['valid'], VAL_LIMIT, indian=False, seed=1)
    val_in = build_eval(items['valid'], VAL_IN_LIMIT, indian=True, seed=2)
    loader = DataLoader(TrainSet(items['train']), batch_size=BATCH, shuffle=True, num_workers=3,
                        drop_last=True, persistent_workers=True)
    opt = torch.optim.AdamW(model.parameters(), lr=BASE_LR, weight_decay=1e-4)
    budget = args.minutes * 60
    epoch_time = None
    run = {'start_epoch': epoch, 'started': time.strftime('%Y-%m-%d %H:%M')}
    while epoch < TOTAL_EPOCHS:
        elapsed = time.time() - t0
        if epoch_time and elapsed + epoch_time * 1.2 > budget:
            break
        lr = BASE_LR * 0.5 * (1 + math.cos(math.pi * epoch / TOTAL_EPOCHS))
        for g in opt.param_groups:
            g['lr'] = lr
        e0, total, n = time.time(), 0.0, 0
        for x, y in loader:
            loss = loss_fn(model(x), y)
            opt.zero_grad(set_to_none=True)
            loss.backward()
            opt.step()
            total += float(loss)
            n += 1
        epoch += 1
        p, r, f = evaluate(model, val)
        pi, ri, fi = evaluate(model, val_in)
        score = (f + fi) / 2
        epoch_time = time.time() - e0
        rec = {'epoch': epoch, 'loss': total / max(n, 1), 'lr': lr, 'P': p, 'R': r, 'F1': f,
               'P_in': pi, 'R_in': ri, 'F1_in': fi, 'score': score, 'secs': round(epoch_time)}
        history['epochs'].append(rec)
        print(json.dumps(rec), flush=True)
        if score > best:
            best = score
            torch.save(model.state_dict(), os.path.join(args.models, 'best_weights.pt'))
            diff = export_onnx(model, os.path.join(args.models, 'plate_finder.onnx'))
            print(f'  new best {best:.3f}, ONNX exported (max diff {diff:.2e})', flush=True)
        torch.save({'model': model.state_dict(), 'epoch': epoch, 'best': best}, state_path)
        json.dump(history, open(hist_path, 'w'), indent=1)

    # final score of the best model on the untouched test photos
    best_w = os.path.join(args.models, 'best_weights.pt')
    if os.path.exists(best_w):
        model.load_state_dict(torch.load(best_w, map_location='cpu', weights_only=True))
        test = build_eval(items['test'], 10_000, indian=False, seed=3)
        test_in = build_eval(items['test'], 10_000, indian=True, seed=4)
        p, r, f = evaluate(model, test)
        pi, ri, fi = evaluate(model, test_in)
        run.update({'end_epoch': epoch, 'best': best, 'test': [p, r, f], 'test_in': [pi, ri, fi]})
        note(f'TEST photos: precision {p:.3f}, recall {r:.3f}, F1 {f:.3f}', 'Result')
        note(f'TEST with Indian plates: precision {pi:.3f}, recall {ri:.3f}, F1 {fi:.3f}', 'Result')
    history['runs'].append(run)
    json.dump(history, open(hist_path, 'w'), indent=1)
    last = history['epochs'][-1] if history['epochs'] else {}
    note(f"Epoch {epoch}/{TOTAL_EPOCHS} · best score {best:.3f} · last F1 {last.get('F1', 0):.3f} "
         f"(Indian {last.get('F1_in', 0):.3f}) · {last.get('secs', 0)} s per epoch", 'Progress')


if __name__ == '__main__':
    main()
